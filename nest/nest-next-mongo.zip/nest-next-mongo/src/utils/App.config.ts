export const AppConfig = {
    site_name: 'Nest-Next-Mongo',
    title: 'Nest Nest Mongo',
    description: 'this is a monorepo skeleton build with Nest.js (Node), Next.js (React) and Mongoose (MongoDB). Featuring ESLint, TypeScript, TailwindCSS and much more!',
    locale: 'en',
};