"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/about";
exports.ids = ["pages/about"];
exports.modules = {

/***/ "./src/pages/about.tsx":
/*!*****************************!*\
  !*** ./src/pages/about.tsx ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   \"getServerSideProps\": () => (/* binding */ getServerSideProps)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst About = ({ data  })=>{\n    const aboutInfo = data.message ? data.message : null;\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n            children: [\n                \"Information about this site: \",\n                aboutInfo,\n                \"!\"\n            ]\n        }, void 0, true, {\n            fileName: \"/Users/administrator/Workspace/nestjs/nest-next-mongo/src/pages/about.tsx\",\n            lineNumber: 13,\n            columnNumber: 7\n        }, undefined)\n    }, void 0, false, {\n        fileName: \"/Users/administrator/Workspace/nestjs/nest-next-mongo/src/pages/about.tsx\",\n        lineNumber: 12,\n        columnNumber: 5\n    }, undefined);\n};\nasync function getServerSideProps(ctx) {\n    const baseUrl = `${process.env.CLIENT_HOST}:${process.env.PORT}`;\n    const resData = await fetch(`${baseUrl}/api/about`, {\n        method: \"GET\"\n    });\n    const data = await resData.json();\n    return {\n        props: {\n            data\n        }\n    };\n}\n// export const getServerSideProps: GetServerSideProps<Props> = async () => {\n//   const baseUrl = `${process.env.CLIENT_HOST}:${process.env.PORT}`;\n//   const resData = await fetch(`${baseUrl}/api/blog/post`, {\n//     method: 'GET',\n//   });\n//   const posts = await resData.json();\n//   return { props: { posts } };\n// };\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (About);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvYWJvdXQudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBO0FBQStCO0FBTy9CLE1BQU1DLEtBQUssR0FBb0IsQ0FBQyxFQUFFQyxJQUFJLEdBQUUsR0FBSztJQUMzQyxNQUFNQyxTQUFTLEdBQUdELElBQUksQ0FBQ0UsT0FBTyxHQUFHRixJQUFJLENBQUNFLE9BQU8sR0FBRyxJQUFJO0lBRXBELHFCQUNFLDhEQUFDQyxLQUFHO2tCQUNGLDRFQUFDQSxLQUFHOztnQkFBQywrQkFBNkI7Z0JBQUNGLFNBQVM7Z0JBQUMsR0FBQzs7Ozs7O3FCQUFNOzs7OztpQkFDaEQsQ0FDTjtDQUNIO0FBRU0sZUFBZUcsa0JBQWtCLENBQUNDLEdBQW9CLEVBQUU7SUFDN0QsTUFBTUMsT0FBTyxHQUFHLENBQUMsRUFBRUMsT0FBTyxDQUFDQyxHQUFHLENBQUNDLFdBQVcsQ0FBQyxDQUFDLEVBQUVGLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDRSxJQUFJLENBQUMsQ0FBQztJQUNoRSxNQUFNQyxPQUFPLEdBQUcsTUFBTUMsS0FBSyxDQUFDLENBQUMsRUFBRU4sT0FBTyxDQUFDLFVBQVUsQ0FBQyxFQUFFO1FBQ2xETyxNQUFNLEVBQUUsS0FBSztLQUNkLENBQUM7SUFFRixNQUFNYixJQUFJLEdBQUcsTUFBTVcsT0FBTyxDQUFDRyxJQUFJLEVBQUU7SUFDakMsT0FBTztRQUFFQyxLQUFLLEVBQUU7WUFBRWYsSUFBSTtTQUFFO0tBQUUsQ0FBQztDQUM1QjtBQUVELDZFQUE2RTtBQUM3RSxzRUFBc0U7QUFDdEUsOERBQThEO0FBQzlELHFCQUFxQjtBQUNyQixRQUFRO0FBRVIsd0NBQXdDO0FBQ3hDLGlDQUFpQztBQUNqQyxLQUFLO0FBRUwsaUVBQWVELEtBQUssRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL25lc3QtbmV4dC1tb25nby8uL3NyYy9wYWdlcy9hYm91dC50c3g/NzNmMiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBOZXh0UGFnZSwgTmV4dFBhZ2VDb250ZXh0IH0gZnJvbSAnbmV4dCc7XG5cbmludGVyZmFjZSBQcm9wcyB7XG4gIHF1ZXJ5OiB7IG5hbWU/OiBzdHJpbmcgfTtcbn1cblxuY29uc3QgQWJvdXQ6IE5leHRQYWdlPFByb3BzPiA9ICh7IGRhdGEgfSkgPT4ge1xuICBjb25zdCBhYm91dEluZm8gPSBkYXRhLm1lc3NhZ2UgPyBkYXRhLm1lc3NhZ2UgOiBudWxsO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxkaXY+SW5mb3JtYXRpb24gYWJvdXQgdGhpcyBzaXRlOiB7YWJvdXRJbmZvfSE8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTZXJ2ZXJTaWRlUHJvcHMoY3R4OiBOZXh0UGFnZUNvbnRleHQpIHtcbiAgY29uc3QgYmFzZVVybCA9IGAke3Byb2Nlc3MuZW52LkNMSUVOVF9IT1NUfToke3Byb2Nlc3MuZW52LlBPUlR9YDtcbiAgY29uc3QgcmVzRGF0YSA9IGF3YWl0IGZldGNoKGAke2Jhc2VVcmx9L2FwaS9hYm91dGAsIHtcbiAgICBtZXRob2Q6ICdHRVQnLFxuICB9KTtcblxuICBjb25zdCBkYXRhID0gYXdhaXQgcmVzRGF0YS5qc29uKCk7XG4gIHJldHVybiB7IHByb3BzOiB7IGRhdGEgfSB9O1xufVxuXG4vLyBleHBvcnQgY29uc3QgZ2V0U2VydmVyU2lkZVByb3BzOiBHZXRTZXJ2ZXJTaWRlUHJvcHM8UHJvcHM+ID0gYXN5bmMgKCkgPT4ge1xuLy8gICBjb25zdCBiYXNlVXJsID0gYCR7cHJvY2Vzcy5lbnYuQ0xJRU5UX0hPU1R9OiR7cHJvY2Vzcy5lbnYuUE9SVH1gO1xuLy8gICBjb25zdCByZXNEYXRhID0gYXdhaXQgZmV0Y2goYCR7YmFzZVVybH0vYXBpL2Jsb2cvcG9zdGAsIHtcbi8vICAgICBtZXRob2Q6ICdHRVQnLFxuLy8gICB9KTtcblxuLy8gICBjb25zdCBwb3N0cyA9IGF3YWl0IHJlc0RhdGEuanNvbigpO1xuLy8gICByZXR1cm4geyBwcm9wczogeyBwb3N0cyB9IH07XG4vLyB9O1xuXG5leHBvcnQgZGVmYXVsdCBBYm91dDtcblxuIl0sIm5hbWVzIjpbIlJlYWN0IiwiQWJvdXQiLCJkYXRhIiwiYWJvdXRJbmZvIiwibWVzc2FnZSIsImRpdiIsImdldFNlcnZlclNpZGVQcm9wcyIsImN0eCIsImJhc2VVcmwiLCJwcm9jZXNzIiwiZW52IiwiQ0xJRU5UX0hPU1QiLCJQT1JUIiwicmVzRGF0YSIsImZldGNoIiwibWV0aG9kIiwianNvbiIsInByb3BzIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/pages/about.tsx\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./src/pages/about.tsx"));
module.exports = __webpack_exports__;

})();