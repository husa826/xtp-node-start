"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/index";
exports.ids = ["pages/index"];
exports.modules = {

/***/ "./src/pages/index.tsx":
/*!*****************************!*\
  !*** ./src/pages/index.tsx ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   \"getServerSideProps\": () => (/* binding */ getServerSideProps)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst Home = ({ data  })=>{\n    const greetName = data.name ? data.name : \"World\";\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n            children: [\n                \"Hello, \",\n                greetName,\n                \"!\"\n            ]\n        }, void 0, true, {\n            fileName: \"/Users/administrator/Workspace/nestjs/nest-next-mongo/src/pages/index.tsx\",\n            lineNumber: 13,\n            columnNumber: 7\n        }, undefined)\n    }, void 0, false, {\n        fileName: \"/Users/administrator/Workspace/nestjs/nest-next-mongo/src/pages/index.tsx\",\n        lineNumber: 12,\n        columnNumber: 5\n    }, undefined);\n};\nasync function getServerSideProps(ctx) {\n    const baseUrl = `${process.env.CLIENT_HOST}:${process.env.PORT}`;\n    const resData = await fetch(`${baseUrl}/api/home`, {\n        method: \"GET\"\n    });\n    const data = await resData.json();\n    return {\n        props: {\n            data\n        }\n    };\n}\n// export const getServerSideProps: GetServerSideProps<Props> = async () => {\n//   const baseUrl = `${process.env.CLIENT_HOST}:${process.env.PORT}`;\n//   const resData = await fetch(`${baseUrl}/api/blog/post`, {\n//     method: 'GET',\n//   });\n//   const posts = await resData.json();\n//   return { props: { posts } };\n// };\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Home);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvaW5kZXgudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBO0FBQStCO0FBTy9CLE1BQU1DLElBQUksR0FBb0IsQ0FBQyxFQUFFQyxJQUFJLEdBQUUsR0FBSztJQUMxQyxNQUFNQyxTQUFTLEdBQUdELElBQUksQ0FBQ0UsSUFBSSxHQUFHRixJQUFJLENBQUNFLElBQUksR0FBRyxPQUFPO0lBRWpELHFCQUNFLDhEQUFDQyxLQUFHO2tCQUNGLDRFQUFDQSxLQUFHOztnQkFBQyxTQUFPO2dCQUFDRixTQUFTO2dCQUFDLEdBQUM7Ozs7OztxQkFBTTs7Ozs7aUJBQzFCLENBQ047Q0FDSDtBQUVNLGVBQWVHLGtCQUFrQixDQUFDQyxHQUFvQixFQUFFO0lBQzdELE1BQU1DLE9BQU8sR0FBRyxDQUFDLEVBQUVDLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDQyxXQUFXLENBQUMsQ0FBQyxFQUFFRixPQUFPLENBQUNDLEdBQUcsQ0FBQ0UsSUFBSSxDQUFDLENBQUM7SUFDaEUsTUFBTUMsT0FBTyxHQUFHLE1BQU1DLEtBQUssQ0FBQyxDQUFDLEVBQUVOLE9BQU8sQ0FBQyxTQUFTLENBQUMsRUFBRTtRQUNqRE8sTUFBTSxFQUFFLEtBQUs7S0FDZCxDQUFDO0lBRUYsTUFBTWIsSUFBSSxHQUFHLE1BQU1XLE9BQU8sQ0FBQ0csSUFBSSxFQUFFO0lBQ2pDLE9BQU87UUFBRUMsS0FBSyxFQUFFO1lBQUVmLElBQUk7U0FBRTtLQUFFLENBQUM7Q0FDNUI7QUFFRCw2RUFBNkU7QUFDN0Usc0VBQXNFO0FBQ3RFLDhEQUE4RDtBQUM5RCxxQkFBcUI7QUFDckIsUUFBUTtBQUVSLHdDQUF3QztBQUN4QyxpQ0FBaUM7QUFDakMsS0FBSztBQUVMLGlFQUFlRCxJQUFJLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXN0LW5leHQtbW9uZ28vLi9zcmMvcGFnZXMvaW5kZXgudHN4PzE5YTAiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgTmV4dFBhZ2UsIE5leHRQYWdlQ29udGV4dCB9IGZyb20gJ25leHQnO1xuXG5pbnRlcmZhY2UgUHJvcHMge1xuICBxdWVyeTogeyBuYW1lPzogc3RyaW5nIH07XG59XG5cbmNvbnN0IEhvbWU6IE5leHRQYWdlPFByb3BzPiA9ICh7IGRhdGEgfSkgPT4ge1xuICBjb25zdCBncmVldE5hbWUgPSBkYXRhLm5hbWUgPyBkYXRhLm5hbWUgOiAnV29ybGQnO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxkaXY+SGVsbG8sIHtncmVldE5hbWV9ITwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNlcnZlclNpZGVQcm9wcyhjdHg6IE5leHRQYWdlQ29udGV4dCkge1xuICBjb25zdCBiYXNlVXJsID0gYCR7cHJvY2Vzcy5lbnYuQ0xJRU5UX0hPU1R9OiR7cHJvY2Vzcy5lbnYuUE9SVH1gO1xuICBjb25zdCByZXNEYXRhID0gYXdhaXQgZmV0Y2goYCR7YmFzZVVybH0vYXBpL2hvbWVgLCB7XG4gICAgbWV0aG9kOiAnR0VUJyxcbiAgfSk7XG5cbiAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc0RhdGEuanNvbigpO1xuICByZXR1cm4geyBwcm9wczogeyBkYXRhIH0gfTtcbn1cblxuLy8gZXhwb3J0IGNvbnN0IGdldFNlcnZlclNpZGVQcm9wczogR2V0U2VydmVyU2lkZVByb3BzPFByb3BzPiA9IGFzeW5jICgpID0+IHtcbi8vICAgY29uc3QgYmFzZVVybCA9IGAke3Byb2Nlc3MuZW52LkNMSUVOVF9IT1NUfToke3Byb2Nlc3MuZW52LlBPUlR9YDtcbi8vICAgY29uc3QgcmVzRGF0YSA9IGF3YWl0IGZldGNoKGAke2Jhc2VVcmx9L2FwaS9ibG9nL3Bvc3RgLCB7XG4vLyAgICAgbWV0aG9kOiAnR0VUJyxcbi8vICAgfSk7XG5cbi8vICAgY29uc3QgcG9zdHMgPSBhd2FpdCByZXNEYXRhLmpzb24oKTtcbi8vICAgcmV0dXJuIHsgcHJvcHM6IHsgcG9zdHMgfSB9O1xuLy8gfTtcblxuZXhwb3J0IGRlZmF1bHQgSG9tZTtcbiJdLCJuYW1lcyI6WyJSZWFjdCIsIkhvbWUiLCJkYXRhIiwiZ3JlZXROYW1lIiwibmFtZSIsImRpdiIsImdldFNlcnZlclNpZGVQcm9wcyIsImN0eCIsImJhc2VVcmwiLCJwcm9jZXNzIiwiZW52IiwiQ0xJRU5UX0hPU1QiLCJQT1JUIiwicmVzRGF0YSIsImZldGNoIiwibWV0aG9kIiwianNvbiIsInByb3BzIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/pages/index.tsx\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./src/pages/index.tsx"));
module.exports = __webpack_exports__;

})();