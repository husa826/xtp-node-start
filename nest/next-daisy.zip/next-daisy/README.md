# Next.js + daisyUI Components Showcase

A beautiful, modern component library built with Next.js 14 and daisyUI, featuring a comprehensive showcase of UI components with dark theme support.

![Next.js](https://img.shields.io/badge/Next.js-14-black?style=for-the-badge&logo=next.js)
![daisyUI](https://img.shields.io/badge/daisyUI-4.0+-5A0EF8?style=for-the-badge&logo=daisyui)
![TypeScript](https://img.shields.io/badge/TypeScript-5.0+-3178C6?style=for-the-badge&logo=typescript)
![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-3.0+-38B2AC?style=for-the-badge&logo=tailwind-css)

## 🚀 Features

- **Modern UI Components**: Comprehensive showcase of daisyUI components
- **Dark Theme by Default**: Beautiful dark theme with theme switching capability
- **Responsive Design**: Fully responsive across all devices
- **TypeScript Support**: Full TypeScript integration for better development experience
- **Component Categories**: Organized into logical sections:
  - Buttons (variants, sizes, states)
  - Cards (basic, with badges, profile cards)
  - Forms (contact forms, advanced inputs)
  - Navigation (navbar, breadcrumbs, tabs, drawer)
  - Feedback (alerts, progress, loading, modals)
  - Tables (basic, zebra, hover, compact)

## 🛠️ Tech Stack

- **Framework**: Next.js 14 (App Router)
- **Styling**: Tailwind CSS + daisyUI
- **Language**: TypeScript
- **Fonts**: Geist Sans & Geist Mono
- **Theme**: Dark theme with theme switching

## 📦 Installation

1. **Clone the repository**
   ```bash
   git clone git@github.com:devmax214/next-daisyUI.git
   cd next-daisyUI
   ```

2. **Install dependencies**
   ```bash
   npm install
   # or
   yarn install
   # or
   pnpm install
   ```

3. **Run the development server**
   ```bash
   npm run dev
   # or
   yarn dev
   # or
   pnpm dev
   ```

4. **Open your browser**
   Navigate to [http://localhost:3000](http://localhost:3000)

## 🎨 Component Showcase

### Home Page
- Landing page with hero section
- Navigation with theme switcher
- Links to component examples

### Examples Page (`/examples`)
Interactive showcase organized into tabs:

#### Buttons
- Basic button variants (primary, secondary, accent, ghost, link)
- Button sizes (tiny, small, normal, large)
- Button states (outline, disabled, loading)

#### Cards
- Basic cards with images
- Cards with badges
- Profile cards with avatars

#### Forms
- Contact form with various input types
- Advanced form with selects, ratings, file uploads, toggles

#### Navigation
- Responsive navbar with dropdown menus
- Breadcrumb navigation
- Tab components
- Drawer/sidebar navigation

#### Feedback
- Alert components (info, success, warning, error)
- Progress bars and radial progress
- Loading spinners and animations
- Modal dialogs
- Toast notifications
- Skeleton loading states

#### Tables
- Basic tables
- Zebra-striped tables
- Tables with hover effects
- Compact tables with pinned rows

## 🎯 Key Features

### Theme System
- **Dark theme by default** for better user experience
- **Theme switcher** in navigation bar
- Support for multiple themes: Light, Dark, Cupcake, Cyberpunk

### Responsive Design
- Mobile-first approach
- Responsive grid layouts
- Adaptive navigation
- Touch-friendly components

### Accessibility
- Semantic HTML structure
- ARIA labels and roles
- Keyboard navigation support
- Screen reader friendly

## 📁 Project Structure

```
next-daisyUI/
├── src/
│   └── app/
│       ├── layout.tsx          # Root layout with navigation
│       ├── page.tsx            # Home page
│       ├── examples/
│       │   └── page.tsx        # Component showcase
│       ├── globals.css         # Global styles
│       └── favicon.ico
├── public/                     # Static assets
├── package.json
├── tailwind.config.js          # Tailwind + daisyUI config
└── README.md
```

## 🚀 Deployment

### Vercel (Recommended)
1. Push your code to GitHub
2. Connect your repository to [Vercel](https://vercel.com)
3. Deploy automatically on every push

### Other Platforms
- **Netlify**: Connect your GitHub repo
- **Railway**: Deploy with one click
- **Docker**: Build and deploy containerized

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📝 License

This project is open source and available under the [MIT License](LICENSE).

## 🙏 Acknowledgments

- [Next.js](https://nextjs.org/) - The React framework
- [daisyUI](https://daisyui.com/) - Tailwind CSS component library
- [Tailwind CSS](https://tailwindcss.com/) - Utility-first CSS framework
- [Geist Font](https://vercel.com/font) - Beautiful typography

## 📞 Support

If you have any questions or need help, feel free to:
- Open an issue on GitHub
- Contact the maintainer
- Check the [daisyUI documentation](https://daisyui.com/)

---

Made with ❤️ using Next.js and daisyUI
