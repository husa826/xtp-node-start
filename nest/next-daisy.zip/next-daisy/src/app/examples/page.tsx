'use client';

import { useState } from 'react';

export default function ExamplesPage() {
  const [activeTab, setActiveTab] = useState('buttons');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  return (
    <div className="min-h-screen bg-base-100">
      {/* Hero Section */}
      <div className="hero min-h-[40vh] bg-gradient-to-r from-primary to-secondary">
        <div className="hero-content text-center text-neutral-content">
          <div className="max-w-md">
            <h1 className="mb-5 text-5xl font-bold">daisyUI Components</h1>
            <p className="mb-5">
              Explore beautiful, accessible components built with Tailwind CSS
            </p>
            <button className="btn btn-primary">Get Started</button>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="container mx-auto px-4 py-8">
        <div className="tabs tabs-boxed justify-center mb-8 gap-4">
          <button 
            className={`tab ${activeTab === 'buttons' ? 'tab-active' : ''}`}
            onClick={() => setActiveTab('buttons')}
          >
            Buttons
          </button>
          <button 
            className={`tab ${activeTab === 'cards' ? 'tab-active' : ''}`}
            onClick={() => setActiveTab('cards')}
          >
            Cards
          </button>
          <button 
            className={`tab ${activeTab === 'forms' ? 'tab-active' : ''}`}
            onClick={() => setActiveTab('forms')}
          >
            Forms
          </button>
          <button 
            className={`tab ${activeTab === 'navigation' ? 'tab-active' : ''}`}
            onClick={() => setActiveTab('navigation')}
          >
            Navigation
          </button>
          <button 
            className={`tab ${activeTab === 'feedback' ? 'tab-active' : ''}`}
            onClick={() => setActiveTab('feedback')}
          >
            Feedback
          </button>
          <button 
            className={`tab ${activeTab === 'tables' ? 'tab-active' : ''}`}
            onClick={() => setActiveTab('tables')}
          >
            Tables
          </button>
        </div>

        {/* Content Sections */}
        <div className="space-y-12">
          {/* Buttons Section */}
          {activeTab === 'buttons' && (
            <div className="space-y-8">
              <h2 className="text-3xl font-bold text-center mb-8">Button Components</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {/* Basic Buttons */}
                <div className="card bg-base-200 shadow-xl">
                  <div className="card-body">
                    <h3 className="card-title">Basic Buttons</h3>
                    <div className="flex flex-wrap gap-2">
                      <button className="btn">Default</button>
                      <button className="btn btn-primary">Primary</button>
                      <button className="btn btn-secondary">Secondary</button>
                      <button className="btn btn-accent">Accent</button>
                      <button className="btn btn-ghost">Ghost</button>
                      <button className="btn btn-link">Link</button>
                    </div>
                  </div>
                </div>

                {/* Button Sizes */}
                <div className="card bg-base-200 shadow-xl">
                  <div className="card-body">
                    <h3 className="card-title">Button Sizes</h3>
                    <div className="flex flex-wrap gap-2 items-center">
                      <button className="btn btn-xs">Tiny</button>
                      <button className="btn btn-sm">Small</button>
                      <button className="btn">Normal</button>
                      <button className="btn btn-lg">Large</button>
                    </div>
                  </div>
                </div>

                {/* Button States */}
                <div className="card bg-base-200 shadow-xl">
                  <div className="card-body">
                    <h3 className="card-title">Button States</h3>
                    <div className="flex flex-wrap gap-2">
                      <button className="btn btn-outline">Outline</button>
                      <button className="btn btn-disabled" disabled>Disabled</button>
                      <button className="btn loading">Loading</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Cards Section */}
          {activeTab === 'cards' && (
            <div className="space-y-8">
              <h2 className="text-3xl font-bold text-center mb-8">Card Components</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {/* Basic Card */}
                <div className="card bg-base-100 shadow-xl">
                  <figure><img src="https://daisyui.com/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes" /></figure>
                  <div className="card-body">
                    <h2 className="card-title">Basic Card</h2>
                    <p>This is a basic card component with an image and content.</p>
                    <div className="card-actions justify-end">
                      <button className="btn btn-primary">Buy Now</button>
                    </div>
                  </div>
                </div>

                {/* Card with Badge */}
                <div className="card bg-base-100 shadow-xl">
                  <figure className="relative">
                    <img src="https://daisyui.com/images/stock/photo-1606107557195-0e29a4b5b4aa.jpg" alt="Shoes" />
                    <div className="badge badge-secondary absolute top-2 right-2">NEW</div>
                  </figure>
                  <div className="card-body">
                    <h2 className="card-title">Card with Badge</h2>
                    <p>Card with a badge indicator in the top-right corner.</p>
                    <div className="card-actions justify-end">
                      <button className="btn btn-outline">Details</button>
                      <button className="btn btn-primary">Add to Cart</button>
                    </div>
                  </div>
                </div>

                {/* Profile Card */}
                <div className="card bg-base-100 shadow-xl">
                  <div className="card-body items-center text-center">
                    <div className="avatar">
                      <div className="w-24 rounded-full">
                        <img src="https://daisyui.com/images/stock/photo-1534528741775-53994a69daeb.jpg" />
                      </div>
                    </div>
                    <h2 className="card-title">John Doe</h2>
                    <p>Software Developer</p>
                    <div className="card-actions">
                      <button className="btn btn-primary">Follow</button>
                      <button className="btn btn-ghost">Message</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Forms Section */}
          {activeTab === 'forms' && (
            <div className="space-y-8">
              <h2 className="text-3xl font-bold text-center mb-8">Form Components</h2>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Contact Form */}
                <div className="card bg-base-200 shadow-xl">
                  <div className="card-body">
                    <h3 className="card-title">Contact Form</h3>
                    <form className="space-y-4">
                      <div className="form-control">
                        <label className="label">
                          <span className="label-text">Name</span>
                        </label>
                        <input type="text" placeholder="Your name" className="input input-bordered" />
                      </div>
                      
                      <div className="form-control">
                        <label className="label">
                          <span className="label-text">Email</span>
                        </label>
                        <input type="email" placeholder="your@email.com" className="input input-bordered" />
                      </div>
                      
                      <div className="form-control">
                        <label className="label">
                          <span className="label-text">Message</span>
                        </label>
                        <textarea className="textarea textarea-bordered" placeholder="Your message"></textarea>
                      </div>
                      
                      <div className="form-control">
                        <label className="label cursor-pointer">
                          <span className="label-text">Subscribe to newsletter</span>
                          <input type="checkbox" className="checkbox checkbox-primary" />
                        </label>
                      </div>
                      
                      <button className="btn btn-primary w-full">Send Message</button>
                    </form>
                  </div>
                </div>

                {/* Advanced Form */}
                <div className="card bg-base-200 shadow-xl">
                  <div className="card-body">
                    <h3 className="card-title">Advanced Form</h3>
                    <form className="space-y-4">
                      <div className="form-control">
                        <label className="label">
                          <span className="label-text">Select Category</span>
                        </label>
                        <select className="select select-bordered">
                          <option disabled selected>Pick one</option>
                          <option>Technology</option>
                          <option>Design</option>
                          <option>Business</option>
                        </select>
                      </div>
                      
                      <div className="form-control">
                        <label className="label">
                          <span className="label-text">Rating</span>
                        </label>
                        <div className="rating">
                          <input type="radio" name="rating-2" className="mask mask-star-2 bg-orange-400" />
                          <input type="radio" name="rating-2" className="mask mask-star-2 bg-orange-400" checked />
                          <input type="radio" name="rating-2" className="mask mask-star-2 bg-orange-400" />
                          <input type="radio" name="rating-2" className="mask mask-star-2 bg-orange-400" />
                          <input type="radio" name="rating-2" className="mask mask-star-2 bg-orange-400" />
                        </div>
                      </div>
                      
                      <div className="form-control">
                        <label className="label">
                          <span className="label-text">File Upload</span>
                        </label>
                        <input type="file" className="file-input file-input-bordered w-full" />
                      </div>
                      
                      <div className="form-control">
                        <label className="label cursor-pointer">
                          <span className="label-text">Toggle Switch</span>
                          <input type="checkbox" className="toggle toggle-primary" />
                        </label>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Navigation Section */}
          {activeTab === 'navigation' && (
            <div className="space-y-8">
              <h2 className="text-3xl font-bold text-center mb-8">Navigation Components</h2>
              
              <div className="space-y-8">
                {/* Navbar */}
                <div className="card bg-base-200 shadow-xl">
                  <div className="card-body">
                    <h3 className="card-title">Navbar</h3>
                    <div className="navbar bg-base-100 rounded-box">
                      <div className="navbar-start">
                        <div className="dropdown">
                          <div tabIndex={0} role="button" className="btn btn-ghost lg:hidden">
                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h8m-8 6h16"></path>
                            </svg>
                          </div>
                          <ul tabIndex={0} className="menu menu-sm dropdown-content mt-3 z-[1] p-2 shadow bg-base-100 rounded-box w-52">
                            <li><a>Item 1</a></li>
                            <li><a>Parent</a>
                              <ul className="p-2">
                                <li><a>Submenu 1</a></li>
                                <li><a>Submenu 2</a></li>
                              </ul>
                            </li>
                            <li><a>Item 3</a></li>
                          </ul>
                        </div>
                        <a className="btn btn-ghost text-xl">daisyUI</a>
                      </div>
                      <div className="navbar-center hidden lg:flex">
                        <ul className="menu menu-horizontal px-1">
                          <li><a>Home</a></li>
                          <li>
                            <details>
                              <summary>Parent</summary>
                              <ul className="p-2">
                                <li><a>Submenu 1</a></li>
                                <li><a>Submenu 2</a></li>
                              </ul>
                            </details>
                          </li>
                          <li><a>About</a></li>
                        </ul>
                      </div>
                      <div className="navbar-end">
                        <a className="btn">Get started</a>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Breadcrumbs */}
                <div className="card bg-base-200 shadow-xl">
                  <div className="card-body">
                    <h3 className="card-title">Breadcrumbs</h3>
                    <div className="text-sm breadcrumbs">
                      <ul>
                        <li><a>Home</a></li>
                        <li><a>Documents</a></li>
                        <li>Add Document</li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Tabs */}
                <div className="card bg-base-200 shadow-xl">
                  <div className="card-body">
                    <h3 className="card-title">Tabs</h3>
                    <div role="tablist" className="tabs tabs-lifted">
                      <input type="radio" name="my_tabs_2" role="tab" className="tab" aria-label="Tab 1" />
                      <div role="tabpanel" className="tab-content bg-base-100 border-base-300 rounded-box p-6">Tab content 1</div>
                      
                      <input type="radio" name="my_tabs_2" role="tab" className="tab" aria-label="Tab 2" checked />
                      <div role="tabpanel" className="tab-content bg-base-100 border-base-300 rounded-box p-6">Tab content 2</div>
                      
                      <input type="radio" name="my_tabs_2" role="tab" className="tab" aria-label="Tab 3" />
                      <div role="tabpanel" className="tab-content bg-base-100 border-base-300 rounded-box p-6">Tab content 3</div>
                    </div>
                  </div>
                </div>

                {/* Drawer */}
                <div className="card bg-base-200 shadow-xl">
                  <div className="card-body">
                    <h3 className="card-title">Drawer</h3>
                    <button className="btn btn-primary" onClick={() => setIsDrawerOpen(true)}>
                      Open Drawer
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Feedback Section */}
          {activeTab === 'feedback' && (
            <div className="space-y-8">
              <h2 className="text-3xl font-bold text-center mb-8">Feedback Components</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {/* Alerts */}
                <div className="card bg-base-200 shadow-xl">
                  <div className="card-body">
                    <h3 className="card-title">Alerts</h3>
                    <div className="space-y-2">
                      <div className="alert alert-info">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" className="stroke-current shrink-0 w-6 h-6">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                        <span>New software update available.</span>
                      </div>
                      <div className="alert alert-success">
                        <svg xmlns="http://www.w3.org/2000/svg" className="stroke-current shrink-0 h-6 w-6" fill="none" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <span>Your purchase has been confirmed!</span>
                      </div>
                      <div className="alert alert-warning">
                        <svg xmlns="http://www.w3.org/2000/svg" className="stroke-current shrink-0 h-6 w-6" fill="none" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
                        </svg>
                        <span>Warning: Invalid email address!</span>
                      </div>
                      <div className="alert alert-error">
                        <svg xmlns="http://www.w3.org/2000/svg" className="stroke-current shrink-0 h-6 w-6" fill="none" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <span>Error! Task failed successfully.</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Progress */}
                <div className="card bg-base-200 shadow-xl">
                  <div className="card-body">
                    <h3 className="card-title">Progress</h3>
                    <div className="space-y-4">
                      <div>
                        <span className="text-sm">Progress Bar</span>
                        <progress className="progress progress-primary w-full" value="70" max="100"></progress>
                      </div>
                      <div>
                        <span className="text-sm">Radial Progress</span>
                        <div className="radial-progress text-primary" style={{"--value": "70"}}>70%</div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Loading */}
                <div className="card bg-base-200 shadow-xl">
                  <div className="card-body">
                    <h3 className="card-title">Loading</h3>
                    <div className="space-y-4">
                      <span className="loading loading-spinner loading-md"></span>
                      <span className="loading loading-dots loading-md"></span>
                      <span className="loading loading-ring loading-md"></span>
                      <span className="loading loading-ball loading-md"></span>
                      <span className="loading loading-bars loading-md"></span>
                      <span className="loading loading-infinity loading-md"></span>
                    </div>
                  </div>
                </div>

                {/* Skeleton */}
                <div className="card bg-base-200 shadow-xl">
                  <div className="card-body">
                    <h3 className="card-title">Skeleton</h3>
                    <div className="space-y-4">
                      <div className="skeleton h-4 w-full"></div>
                      <div className="skeleton h-4 w-28"></div>
                      <div className="skeleton h-4 w-full"></div>
                      <div className="skeleton h-4 w-full"></div>
                      <div className="skeleton h-4 w-3/4"></div>
                    </div>
                  </div>
                </div>

                {/* Modal */}
                <div className="card bg-base-200 shadow-xl">
                  <div className="card-body">
                    <h3 className="card-title">Modal</h3>
                    <button className="btn btn-primary" onClick={() => setIsModalOpen(true)}>
                      Open Modal
                    </button>
                  </div>
                </div>

                {/* Toast */}
                <div className="card bg-base-200 shadow-xl">
                  <div className="card-body">
                    <h3 className="card-title">Toast</h3>
                    <div className="toast toast-end">
                      <div className="alert alert-info">
                        <span>New message arrived.</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Tables Section */}
          {activeTab === 'tables' && (
            <div className="space-y-8">
              <h2 className="text-3xl font-bold text-center mb-8">Table Components</h2>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Basic Table */}
                <div className="card bg-base-200 shadow-xl">
                  <div className="card-body">
                    <h3 className="card-title">Basic Table</h3>
                    <div className="overflow-x-auto">
                      <table className="table">
                        <thead>
                          <tr>
                            <th>Name</th>
                            <th>Job</th>
                            <th>Favorite Color</th>
                            <th></th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>Cy Ganderton</td>
                            <td>Quality Control Specialist</td>
                            <td>Blue</td>
                            <th>
                              <button className="btn btn-ghost btn-xs">details</button>
                            </th>
                          </tr>
                          <tr>
                            <td>Hart Hagerty</td>
                            <td>Desktop Support Technician</td>
                            <td>Purple</td>
                            <th>
                              <button className="btn btn-ghost btn-xs">details</button>
                            </th>
                          </tr>
                          <tr>
                            <td>Brice Swyre</td>
                            <td>Tax Accountant</td>
                            <td>Red</td>
                            <th>
                              <button className="btn btn-ghost btn-xs">details</button>
                            </th>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>

                {/* Zebra Table */}
                <div className="card bg-base-200 shadow-xl">
                  <div className="card-body">
                    <h3 className="card-title">Zebra Table</h3>
                    <div className="overflow-x-auto">
                      <table className="table table-zebra">
                        <thead>
                          <tr>
                            <th>Name</th>
                            <th>Job</th>
                            <th>Favorite Color</th>
                            <th></th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>Cy Ganderton</td>
                            <td>Quality Control Specialist</td>
                            <td>Blue</td>
                            <th>
                              <button className="btn btn-ghost btn-xs">details</button>
                            </th>
                          </tr>
                          <tr>
                            <td>Hart Hagerty</td>
                            <td>Desktop Support Technician</td>
                            <td>Purple</td>
                            <th>
                              <button className="btn btn-ghost btn-xs">details</button>
                            </th>
                          </tr>
                          <tr>
                            <td>Brice Swyre</td>
                            <td>Tax Accountant</td>
                            <td>Red</td>
                            <th>
                              <button className="btn btn-ghost btn-xs">details</button>
                            </th>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>

                {/* Table with Hover */}
                <div className="card bg-base-200 shadow-xl">
                  <div className="card-body">
                    <h3 className="card-title">Table with Hover</h3>
                    <div className="overflow-x-auto">
                      <table className="table table-hover">
                        <thead>
                          <tr>
                            <th>Name</th>
                            <th>Job</th>
                            <th>Favorite Color</th>
                            <th></th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>Cy Ganderton</td>
                            <td>Quality Control Specialist</td>
                            <td>Blue</td>
                            <th>
                              <button className="btn btn-ghost btn-xs">details</button>
                            </th>
                          </tr>
                          <tr>
                            <td>Hart Hagerty</td>
                            <td>Desktop Support Technician</td>
                            <td>Purple</td>
                            <th>
                              <button className="btn btn-ghost btn-xs">details</button>
                            </th>
                          </tr>
                          <tr>
                            <td>Brice Swyre</td>
                            <td>Tax Accountant</td>
                            <td>Red</td>
                            <th>
                              <button className="btn btn-ghost btn-xs">details</button>
                            </th>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>

                {/* Compact Table */}
                <div className="card bg-base-200 shadow-xl">
                  <div className="card-body">
                    <h3 className="card-title">Compact Table</h3>
                    <div className="overflow-x-auto">
                      <table className="table table-zebra table-pin-rows">
                        <thead>
                          <tr>
                            <th>Name</th>
                            <th>Job</th>
                            <th>Favorite Color</th>
                            <th></th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>Cy Ganderton</td>
                            <td>Quality Control Specialist</td>
                            <td>Blue</td>
                            <th>
                              <button className="btn btn-ghost btn-xs">details</button>
                            </th>
                          </tr>
                          <tr>
                            <td>Hart Hagerty</td>
                            <td>Desktop Support Technician</td>
                            <td>Purple</td>
                            <th>
                              <button className="btn btn-ghost btn-xs">details</button>
                            </th>
                          </tr>
                          <tr>
                            <td>Brice Swyre</td>
                            <td>Tax Accountant</td>
                            <td>Red</td>
                            <th>
                              <button className="btn btn-ghost btn-xs">details</button>
                            </th>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Modal */}
      <dialog className={`modal ${isModalOpen ? 'modal-open' : ''}`}>
        <div className="modal-box">
          <h3 className="font-bold text-lg">Hello!</h3>
          <p className="py-4">This is a modal dialog example from daisyUI.</p>
          <div className="modal-action">
            <form method="dialog">
              <button className="btn" onClick={() => setIsModalOpen(false)}>Close</button>
            </form>
          </div>
        </div>
      </dialog>

      {/* Drawer */}
      <div className={`drawer ${isDrawerOpen ? 'drawer-open' : ''}`}>
        <input id="my-drawer" type="checkbox" className="drawer-toggle" checked={isDrawerOpen} onChange={() => setIsDrawerOpen(!isDrawerOpen)} />
        <div className="drawer-content">
          <label htmlFor="my-drawer" className="btn btn-primary drawer-button">Open drawer</label>
        </div> 
        <div className="drawer-side">
          <label htmlFor="my-drawer" aria-label="close sidebar" className="drawer-overlay" onClick={() => setIsDrawerOpen(false)}></label>
          <ul className="menu p-4 w-80 min-h-full bg-base-200 text-base-content">
            <li><a>Sidebar Item 1</a></li>
            <li><a>Sidebar Item 2</a></li>
            <li><a>Sidebar Item 3</a></li>
          </ul>
        </div>
      </div>
    </div>
  );
} 