export type GoogleConfig = {
  clientId?: string;
  clientSecret?: string;
};
