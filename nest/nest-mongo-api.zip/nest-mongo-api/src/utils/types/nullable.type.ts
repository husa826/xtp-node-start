export type NullableType<T> = T | null;
