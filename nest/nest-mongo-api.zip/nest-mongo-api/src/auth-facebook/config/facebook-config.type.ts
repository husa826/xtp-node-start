export type FacebookConfig = {
  appId?: string;
  appSecret?: string;
};
