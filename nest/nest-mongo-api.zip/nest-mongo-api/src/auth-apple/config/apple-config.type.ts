export type AppleConfig = {
  appAudience: string[];
};
