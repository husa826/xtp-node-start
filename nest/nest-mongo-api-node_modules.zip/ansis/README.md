![](docs/npm.png)

ANSI color lib. [Docs on GitHub](../../)
