# Drone Image Processor - Testing Instructions

This guide provides comprehensive testing instructions for the drone image processor using the complex sample images created for various agricultural scenarios.

## 📋 Prerequisites

1. Ensure all dependencies are installed:
   ```bash
   pip install -r requirements.txt
   ```

2. Verify the sample images directory contains all test images:
   ```bash
   ls -la sample_images/
   ```
   You should see 39 sample images total.

## 🧪 Test Categories

### 1. **Basic Functionality Tests**

#### Test 1.1: Single Image Processing
```bash
python drone_processor.py sample_images/sample_corn_field.jpg
```
**Expected Result**: Single image saved as mosaic (no stitching needed)

#### Test 1.2: Multiple Unique Images
```bash
python drone_processor.py sample_images/sample_corn_field.jpg sample_images/sample_wheat_field.jpg sample_images/sample_farm_equipment.jpg
```
**Expected Result**: Images identified as unique, stitching may fail due to no overlap

#### Test 1.3: Identical Images (Duplicate Detection)
```bash
python drone_processor.py sample_images/sample_morning_lighting.jpg sample_images/sample_noon_lighting.jpg sample_images/sample_evening_lighting.jpg
```
**Expected Result**: Duplicates detected and removed, only one unique image kept

### 2. **Overlap Testing (Stitching Validation)**

#### Test 2.1: 30% Overlap Set (Recommended)
```bash
python drone_processor.py sample_images/overlap_30_part_1.jpg sample_images/overlap_30_part_2.jpg sample_images/overlap_30_part_3.jpg sample_images/overlap_30_part_4.jpg
```
**Expected Result**: 
- Some duplicates detected and removed
- Successful stitching of remaining unique images
- Mosaic saved to `output/farm_mosaic.jpg`

#### Test 2.2: 50% Overlap Set (High Overlap)
```bash
python drone_processor.py sample_images/overlap_50_part_1.jpg sample_images/overlap_50_part_2.jpg sample_images/overlap_50_part_3.jpg sample_images/overlap_50_part_4.jpg
```
**Expected Result**: 
- More duplicates detected due to higher overlap
- Successful stitching with fewer unique images

#### Test 2.3: Minimal Overlap Set (Challenging)
```bash
python drone_processor.py sample_images/overlap_minimal_part_1.jpg sample_images/overlap_minimal_part_2.jpg sample_images/overlap_minimal_part_3.jpg sample_images/overlap_minimal_part_4.jpg
```
**Expected Result**: 
- Fewer duplicates detected
- May fail stitching due to insufficient overlap

### 3. **Weather Condition Tests**

#### Test 3.1: Weather Variations
```bash
python drone_processor.py sample_images/sample_rainy_weather.jpg sample_images/sample_foggy_weather.jpg sample_images/sample_dusty_weather.jpg
```
**Expected Result**: Images processed, stitching may fail due to different weather effects

#### Test 3.2: Weather vs Normal Conditions
```bash
python drone_processor.py sample_images/sample_noon_lighting.jpg sample_images/sample_rainy_weather.jpg
```
**Expected Result**: Duplicate detection should work despite weather differences

### 4. **Crop Type Tests**

#### Test 4.1: Different Crop Types
```bash
python drone_processor.py sample_images/sample_rice_paddy.jpg sample_images/sample_vineyard.jpg sample_images/sample_orchard.jpg
```
**Expected Result**: All images identified as unique, stitching will fail

#### Test 4.2: Similar Crop Types
```bash
python drone_processor.py sample_images/sample_corn_field.jpg sample_images/sample_wheat_field.jpg sample_images/sample_mixed_crops.jpg
```
**Expected Result**: Images identified as unique, stitching may fail

### 5. **Lighting Condition Tests**

#### Test 5.1: Lighting Variations
```bash
python drone_processor.py sample_images/sample_morning_lighting.jpg sample_images/sample_noon_lighting.jpg sample_images/sample_evening_lighting.jpg sample_images/sample_overcast_lighting.jpg
```
**Expected Result**: Duplicates detected due to same scene with different lighting

#### Test 5.2: Extreme Lighting Differences
```bash
python drone_processor.py sample_images/sample_sunny_lighting.jpg sample_images/sample_shadowy_lighting.jpg
```
**Expected Result**: Duplicate detection should still work

### 6. **Complex Scenario Tests**

#### Test 6.1: Farm Equipment and Infrastructure
```bash
python drone_processor.py sample_images/sample_farm_equipment.jpg sample_images/sample_irrigation.jpg sample_images/sample_farm_boundary.jpg
```
**Expected Result**: Unique images, stitching may fail

#### Test 6.2: Mixed Agricultural Scenarios
```bash
python drone_processor.py sample_images/sample_pasture.jpg sample_images/sample_vegetable_garden.jpg sample_images/sample_fallow_field.jpg
```
**Expected Result**: Unique images, stitching will fail

## 🔍 **What to Look For**

### ✅ **Successful Tests Should Show:**
- Images loaded successfully
- Duplicate detection working (overlap percentages calculated)
- Unique images identified correctly
- Successful stitching for overlapping images
- Mosaic saved to `output/farm_mosaic.jpg`

### ❌ **Expected Failures:**
- Stitching fails for non-overlapping images (status: 1)
- Stitching fails for insufficient overlap
- Different crop types can't be stitched together

### 📊 **Performance Indicators:**
- **Duplicate Detection Accuracy**: Should correctly identify overlapping images
- **Stitching Success Rate**: Should work well with 30-50% overlap
- **Processing Speed**: Monitor processing time for different image sets
- **Memory Usage**: Check for memory issues with large image sets

## 🚀 **Advanced Testing**

### Batch Testing Script
Create a test script to run multiple tests automatically:

```bash
# Create test script
cat > run_tests.sh << 'EOF'
#!/bin/bash

echo "=== Drone Image Processor Test Suite ==="
echo

echo "Test 1: Single Image Processing"
python drone_processor.py sample_images/sample_corn_field.jpg
echo

echo "Test 2: 30% Overlap Set"
python drone_processor.py sample_images/overlap_30_part_1.jpg sample_images/overlap_30_part_2.jpg sample_images/overlap_30_part_3.jpg sample_images/overlap_30_part_4.jpg
echo

echo "Test 3: Lighting Variations"
python drone_processor.py sample_images/sample_morning_lighting.jpg sample_images/sample_noon_lighting.jpg sample_images/sample_evening_lighting.jpg
echo

echo "Test 4: Different Crop Types"
python drone_processor.py sample_images/sample_rice_paddy.jpg sample_images/sample_vineyard.jpg sample_images/sample_orchard.jpg
echo

echo "Test 5: Weather Conditions"
python drone_processor.py sample_images/sample_rainy_weather.jpg sample_images/sample_foggy_weather.jpg sample_images/sample_dusty_weather.jpg
echo

echo "=== Test Suite Complete ==="
EOF

chmod +x run_tests.sh
./run_tests.sh
```

### GUI Testing
If tkinter is available, test the GUI interface:
```bash
python drone_processor.py --gui
```

## 📈 **Test Results Documentation**

Keep track of test results:

| Test Category | Test Name | Expected Result | Actual Result | Status |
|---------------|-----------|-----------------|---------------|---------|
| Basic | Single Image | Success | ✅ | Pass |
| Basic | Multiple Unique | Duplicates detected | ✅ | Pass |
| Overlap | 30% Overlap | Successful stitching | ✅ | Pass |
| Overlap | 50% Overlap | Successful stitching | ✅ | Pass |
| Overlap | Minimal Overlap | Stitching may fail | ❌ | Expected |
| Weather | Weather Variations | Processing success | ✅ | Pass |
| Crop | Different Crops | Unique detection | ✅ | Pass |
| Lighting | Lighting Variations | Duplicate detection | ✅ | Pass |

## 🐛 **Troubleshooting**

### Common Issues:
1. **Stitching Fails**: Normal for non-overlapping images
2. **Memory Issues**: Process smaller batches
3. **GUI Not Available**: Install tkinter or use command line
4. **Poor Quality**: Try enabling image enhancement

### Debug Commands:
```bash
# Check image properties
python -c "
import cv2
img = cv2.imread('sample_images/sample_corn_field.jpg')
print(f'Image shape: {img.shape}')
print(f'Image size: {img.nbytes/(1024*1024):.2f} MB')
"

# Test individual components
python -c "
from drone_processor import DroneImageProcessor
processor = DroneImageProcessor()
# Test specific functions
"
```

## 📝 **Test Report Template**

After running tests, document your findings:

```
Test Date: [DATE]
Tester: [NAME]
Environment: [OS/Python Version]

Test Results Summary:
- Total Tests Run: [NUMBER]
- Passed: [NUMBER]
- Failed: [NUMBER]
- Expected Failures: [NUMBER]

Key Findings:
- [FINDING 1]
- [FINDING 2]
- [FINDING 3]

Recommendations:
- [RECOMMENDATION 1]
- [RECOMMENDATION 2]
```

---

**Happy Testing!** 🚁📸

These comprehensive tests will help validate your drone image processor's capabilities across various real-world agricultural scenarios.
