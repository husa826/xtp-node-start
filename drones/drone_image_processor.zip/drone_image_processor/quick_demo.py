#!/usr/bin/env python3
"""
Quick Start Guide for Drone Image Processor
This script demonstrates the basic usage of the drone image processor.
"""

import os
import sys
from drone_processor import DroneImageProcessor

def quick_demo():
    """Quick demonstration of the drone image processor."""
    print("🚁 Drone Image Processor - Quick Demo")
    print("=" * 50)
    
    # Initialize processor
    processor = DroneImageProcessor()
    
    # Check if sample images exist
    sample_dir = "sample_images"
    if os.path.exists(sample_dir):
        print(f"✅ Found sample images in {sample_dir}")
        
        # Get sample images
        sample_images = []
        for file in os.listdir(sample_dir):
            if file.lower().endswith(('.jpg', '.jpeg', '.png')):
                sample_images.append(os.path.join(sample_dir, file))
        
        if sample_images:
            print(f"📸 Found {len(sample_images)} sample images")
            
            # Load images
            print("📥 Loading images...")
            if processor.load_images(sample_images):
                print("✅ Images loaded successfully")
                
                # Show image info
                for i, img in enumerate(processor.images):
                    info = processor.get_image_info(img)
                    print(f"   Image {i+1}: {info['width']}x{info['height']} pixels, {info['size_mb']:.2f} MB")
                
                # Process images
                print("\n🔄 Processing images...")
                print("   - Detecting duplicates...")
                print("   - Removing overlapping areas...")
                print("   - Creating mosaic...")
                
                success = processor.create_mosaic()
                
                if success:
                    print("\n🎉 SUCCESS! Mosaic created successfully!")
                    print(f"📁 Output saved to: {processor.output_dir}/farm_mosaic.jpg")
                    
                    # Show final mosaic info
                    info = processor.get_image_info(processor.final_mosaic)
                    print(f"📊 Final mosaic: {info['width']}x{info['height']} pixels")
                    print(f"💾 File size: {info['size_mb']:.2f} MB")
                    
                    print("\n✨ You can now view the processed farm mosaic!")
                else:
                    print("❌ Failed to create mosaic")
            else:
                print("❌ Failed to load images")
        else:
            print("❌ No sample images found")
    else:
        print("❌ Sample images directory not found")
        print("   Run 'python3 example_usage.py' first to create sample images")

def show_usage():
    """Show usage instructions."""
    print("\n📖 USAGE INSTRUCTIONS:")
    print("=" * 30)
    print("1. Command Line Mode:")
    print("   python3 drone_processor.py image1.jpg image2.jpg image3.jpg")
    print()
    print("2. GUI Mode (if tkinter is available):")
    print("   python3 drone_processor.py --gui")
    print()
    print("3. Programmatic Usage:")
    print("   from drone_processor import DroneImageProcessor")
    print("   processor = DroneImageProcessor()")
    print("   processor.load_images(['img1.jpg', 'img2.jpg'])")
    print("   processor.create_mosaic()")
    print()
    print("📁 Output files are saved in the 'output/' directory")
    print("🔧 Supported formats: JPG, PNG, BMP, TIFF")

if __name__ == "__main__":
    quick_demo()
    show_usage()
    
    print("\n🚀 Ready to process your drone images!")
    print("   Place your drone images in a folder and run:")
    print("   python3 drone_processor.py path/to/your/images/*.jpg")
