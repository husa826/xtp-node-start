#!/usr/bin/env python3
"""
Drone Image Processor - Automated Test Script
Runs comprehensive tests on the sample images to validate functionality.
"""

import subprocess
import sys
import os
from datetime import datetime

class DroneProcessorTester:
    def __init__(self):
        self.test_results = []
        self.passed = 0
        self.failed = 0
        self.expected_failures = 0
        
    def run_test(self, test_name, command, expected_success=True, description=""):
        """Run a single test and record results."""
        print(f"\n{'='*60}")
        print(f"TEST: {test_name}")
        print(f"Description: {description}")
        print(f"Command: {' '.join(command)}")
        print(f"{'='*60}")
        
        try:
            result = subprocess.run(command, capture_output=True, text=True, timeout=60)
            
            success = result.returncode == 0
            if success == expected_success:
                status = "✅ PASS"
                if expected_success:
                    self.passed += 1
                else:
                    self.expected_failures += 1
            else:
                status = "❌ FAIL"
                self.failed += 1
            
            print(f"Status: {status}")
            print(f"Return Code: {result.returncode}")
            
            if result.stdout:
                print("STDOUT:")
                print(result.stdout)
            
            if result.stderr:
                print("STDERR:")
                print(result.stderr)
            
            self.test_results.append({
                'name': test_name,
                'command': ' '.join(command),
                'expected_success': expected_success,
                'actual_success': success,
                'status': status,
                'description': description
            })
            
        except subprocess.TimeoutExpired:
            print("❌ TIMEOUT - Test took too long")
            self.failed += 1
            self.test_results.append({
                'name': test_name,
                'command': ' '.join(command),
                'expected_success': expected_success,
                'actual_success': False,
                'status': "❌ TIMEOUT",
                'description': description
            })
        except Exception as e:
            print(f"❌ ERROR - {e}")
            self.failed += 1
            self.test_results.append({
                'name': test_name,
                'command': ' '.join(command),
                'expected_success': expected_success,
                'actual_success': False,
                'status': f"❌ ERROR: {e}",
                'description': description
            })
    
    def run_all_tests(self):
        """Run all test scenarios."""
        print("🚁 Drone Image Processor - Automated Test Suite")
        print(f"Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        # Test 1: Single Image Processing
        self.run_test(
            "Single Image Processing",
            ["python", "drone_processor.py", "sample_images/sample_corn_field.jpg"],
            expected_success=True,
            description="Process a single image (should work)"
        )
        
        # Test 2: Multiple Unique Images (no overlap)
        self.run_test(
            "Multiple Unique Images",
            ["python", "drone_processor.py", 
             "sample_images/sample_corn_field.jpg", 
             "sample_images/sample_wheat_field.jpg", 
             "sample_images/sample_farm_equipment.jpg"],
            expected_success=False,  # Stitching will fail due to no overlap
            description="Process multiple unique images with no overlap (stitching expected to fail)"
        )
        
        # Test 3: Duplicate Detection (lighting variations)
        self.run_test(
            "Duplicate Detection",
            ["python", "drone_processor.py",
             "sample_images/sample_morning_lighting.jpg",
             "sample_images/sample_noon_lighting.jpg",
             "sample_images/sample_evening_lighting.jpg"],
            expected_success=True,
            description="Test duplicate detection with lighting variations (should detect duplicates)"
        )
        
        # Test 4: 30% Overlap Set (should work)
        self.run_test(
            "30% Overlap Stitching",
            ["python", "drone_processor.py",
             "sample_images/overlap_30_part_1.jpg",
             "sample_images/overlap_30_part_2.jpg",
             "sample_images/overlap_30_part_3.jpg",
             "sample_images/overlap_30_part_4.jpg"],
            expected_success=True,
            description="Test stitching with 30% overlap (should succeed)"
        )
        
        # Test 5: 50% Overlap Set (should work)
        self.run_test(
            "50% Overlap Stitching",
            ["python", "drone_processor.py",
             "sample_images/overlap_50_part_1.jpg",
             "sample_images/overlap_50_part_2.jpg",
             "sample_images/overlap_50_part_3.jpg",
             "sample_images/overlap_50_part_4.jpg"],
            expected_success=True,
            description="Test stitching with 50% overlap (should succeed)"
        )
        
        # Test 6: Minimal Overlap (may fail)
        self.run_test(
            "Minimal Overlap Stitching",
            ["python", "drone_processor.py",
             "sample_images/overlap_minimal_part_1.jpg",
             "sample_images/overlap_minimal_part_2.jpg",
             "sample_images/overlap_minimal_part_3.jpg",
             "sample_images/overlap_minimal_part_4.jpg"],
            expected_success=False,  # May fail due to insufficient overlap
            description="Test stitching with minimal overlap (may fail)"
        )
        
        # Test 7: Weather Conditions
        self.run_test(
            "Weather Conditions",
            ["python", "drone_processor.py",
             "sample_images/sample_rainy_weather.jpg",
             "sample_images/sample_foggy_weather.jpg",
             "sample_images/sample_dusty_weather.jpg"],
            expected_success=False,  # Different weather conditions can't be stitched
            description="Test processing different weather conditions (stitching expected to fail)"
        )
        
        # Test 8: Different Crop Types
        self.run_test(
            "Different Crop Types",
            ["python", "drone_processor.py",
             "sample_images/sample_rice_paddy.jpg",
             "sample_images/sample_vineyard.jpg",
             "sample_images/sample_orchard.jpg"],
            expected_success=False,  # Different crop types can't be stitched
            description="Test processing different crop types (stitching expected to fail)"
        )
        
        # Test 9: Mixed Scenarios
        self.run_test(
            "Mixed Agricultural Scenarios",
            ["python", "drone_processor.py",
             "sample_images/sample_pasture.jpg",
             "sample_images/sample_vegetable_garden.jpg",
             "sample_images/sample_fallow_field.jpg"],
            expected_success=False,  # Different scenarios can't be stitched
            description="Test processing mixed agricultural scenarios (stitching expected to fail)"
        )
        
        # Test 10: Extreme Lighting Differences
        self.run_test(
            "Extreme Lighting Differences",
            ["python", "drone_processor.py",
             "sample_images/sample_sunny_lighting.jpg",
             "sample_images/sample_shadowy_lighting.jpg"],
            expected_success=True,
            description="Test duplicate detection with extreme lighting differences"
        )
    
    def generate_report(self):
        """Generate a comprehensive test report."""
        print(f"\n{'='*80}")
        print("📊 TEST RESULTS SUMMARY")
        print(f"{'='*80}")
        print(f"Total Tests Run: {len(self.test_results)}")
        print(f"✅ Passed: {self.passed}")
        print(f"❌ Failed: {self.failed}")
        print(f"⚠️  Expected Failures: {self.expected_failures}")
        print(f"Success Rate: {(self.passed + self.expected_failures) / len(self.test_results) * 100:.1f}%")
        
        print(f"\n{'='*80}")
        print("📋 DETAILED RESULTS")
        print(f"{'='*80}")
        
        for result in self.test_results:
            print(f"\nTest: {result['name']}")
            print(f"Status: {result['status']}")
            print(f"Description: {result['description']}")
            print(f"Command: {result['command']}")
        
        print(f"\n{'='*80}")
        print("🎯 KEY FINDINGS")
        print(f"{'='*80}")
        
        # Analyze results
        stitching_tests = [r for r in self.test_results if 'overlap' in r['name'].lower() or 'stitching' in r['name'].lower()]
        duplicate_tests = [r for r in self.test_results if 'duplicate' in r['name'].lower() or 'lighting' in r['name'].lower()]
        
        print(f"Stitching Tests: {len([r for r in stitching_tests if r['status'] == '✅ PASS'])}/{len(stitching_tests)} passed")
        print(f"Duplicate Detection Tests: {len([r for r in duplicate_tests if r['status'] == '✅ PASS'])}/{len(duplicate_tests)} passed")
        
        print(f"\n{'='*80}")
        print("💡 RECOMMENDATIONS")
        print(f"{'='*80}")
        
        if self.failed > 0:
            print("• Review failed tests to identify potential issues")
        
        if len([r for r in stitching_tests if r['status'] == '✅ PASS']) < len(stitching_tests) // 2:
            print("• Consider improving stitching algorithm for better overlap handling")
        
        if len([r for r in duplicate_tests if r['status'] == '✅ PASS']) == len(duplicate_tests):
            print("• Duplicate detection is working well across different conditions")
        
        print("• Test with real drone images to validate real-world performance")
        print("• Consider adding more edge cases for comprehensive testing")
        
        # Save report to file
        self.save_report()
    
    def save_report(self):
        """Save test report to file."""
        report_filename = f"test_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        
        with open(report_filename, 'w') as f:
            f.write("Drone Image Processor - Test Report\n")
            f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write("="*80 + "\n\n")
            
            f.write(f"Total Tests: {len(self.test_results)}\n")
            f.write(f"Passed: {self.passed}\n")
            f.write(f"Failed: {self.failed}\n")
            f.write(f"Expected Failures: {self.expected_failures}\n\n")
            
            f.write("Detailed Results:\n")
            f.write("-"*40 + "\n")
            
            for result in self.test_results:
                f.write(f"\nTest: {result['name']}\n")
                f.write(f"Status: {result['status']}\n")
                f.write(f"Description: {result['description']}\n")
                f.write(f"Command: {result['command']}\n")
        
        print(f"\n📄 Test report saved to: {report_filename}")

def main():
    """Main function to run the test suite."""
    if not os.path.exists("sample_images"):
        print("❌ Error: sample_images directory not found!")
        print("Please run this script from the drone_image_processor directory.")
        sys.exit(1)
    
    if not os.path.exists("drone_processor.py"):
        print("❌ Error: drone_processor.py not found!")
        print("Please run this script from the drone_image_processor directory.")
        sys.exit(1)
    
    tester = DroneProcessorTester()
    tester.run_all_tests()
    tester.generate_report()

if __name__ == "__main__":
    main()
