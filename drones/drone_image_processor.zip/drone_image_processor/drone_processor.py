#!/usr/bin/env python3
"""
Drone Image Processor
A program to process overlapping drone images of farm grounds and create a complete mosaic.
"""

import cv2
import numpy as np
import os
import sys
from typing import List, Tuple, Optional
import warnings
warnings.filterwarnings('ignore')

# Optional imports for GUI functionality
try:
    from PIL import Image, ImageTk
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
    GUI_AVAILABLE = True
except ImportError:
    GUI_AVAILABLE = False
    print("GUI components not available - tkinter not installed")

try:
    import matplotlib.pyplot as plt
    MATPLOTLIB_AVAILABLE = True
except ImportError:
    MATPLOTLIB_AVAILABLE = False

try:
    from skimage import measure, segmentation
    SKIMAGE_AVAILABLE = True
except ImportError:
    SKIMAGE_AVAILABLE = False


class DroneImageProcessor:
    """Main class for processing drone images and creating mosaics."""
    
    def __init__(self):
        self.images = []
        self.processed_images = []
        self.final_mosaic = None
        self.output_dir = "output"
        
        # Create output directory if it doesn't exist
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)
    
    def load_images(self, image_paths: List[str]) -> bool:
        """Load images from file paths."""
        try:
            self.images = []
            for path in image_paths:
                if os.path.exists(path):
                    img = cv2.imread(path)
                    if img is not None:
                        self.images.append(img)
                        print(f"Loaded image: {os.path.basename(path)}")
                    else:
                        print(f"Failed to load image: {path}")
                else:
                    print(f"File not found: {path}")
            
            return len(self.images) > 0
        except Exception as e:
            print(f"Error loading images: {e}")
            return False
    
    def detect_duplicates(self, img1: np.ndarray, img2: np.ndarray) -> Tuple[bool, float]:
        """Detect if two images have significant overlap."""
        try:
            # Convert to grayscale for feature detection
            gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
            gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
            
            # Initialize SIFT detector
            sift = cv2.SIFT_create()
            
            # Find keypoints and descriptors
            kp1, des1 = sift.detectAndCompute(gray1, None)
            kp2, des2 = sift.detectAndCompute(gray2, None)
            
            if des1 is None or des2 is None:
                return False, 0.0
            
            # Match features
            bf = cv2.BFMatcher()
            matches = bf.knnMatch(des1, des2, k=2)
            
            # Apply ratio test
            good_matches = []
            for match_pair in matches:
                if len(match_pair) == 2:
                    m, n = match_pair
                    if m.distance < 0.75 * n.distance:
                        good_matches.append(m)
            
            # Calculate overlap percentage
            overlap_ratio = len(good_matches) / min(len(kp1), len(kp2))
            
            # Consider images as duplicates if overlap > 30%
            is_duplicate = overlap_ratio > 0.3
            
            return is_duplicate, overlap_ratio
            
        except Exception as e:
            print(f"Error detecting duplicates: {e}")
            return False, 0.0
    
    def stitch_images(self, images: List[np.ndarray]) -> Optional[np.ndarray]:
        """Stitch multiple images together using OpenCV's stitcher."""
        try:
            if len(images) < 2:
                return images[0] if images else None
            
            # Create stitcher
            stitcher = cv2.Stitcher_create()
            
            # Stitch images
            status, stitched = stitcher.stitch(images)
            
            if status == cv2.Stitcher_OK:
                print("Image stitching successful!")
                return stitched
            else:
                print(f"Stitching failed with status: {status}")
                return None
                
        except Exception as e:
            print(f"Error stitching images: {e}")
            return None
    
    def remove_duplicates(self) -> List[np.ndarray]:
        """Remove duplicate images from the loaded set."""
        if len(self.images) < 2:
            return self.images
        
        unique_images = [self.images[0]]  # Start with first image
        
        for i in range(1, len(self.images)):
            is_duplicate = False
            
            for j, unique_img in enumerate(unique_images):
                is_dup, overlap_ratio = self.detect_duplicates(self.images[i], unique_img)
                if is_dup:
                    print(f"Image {i+1} is duplicate of image {j+1} (overlap: {overlap_ratio:.2%})")
                    is_duplicate = True
                    break
            
            if not is_duplicate:
                unique_images.append(self.images[i])
                print(f"Added unique image {i+1}")
        
        print(f"Reduced {len(self.images)} images to {len(unique_images)} unique images")
        return unique_images
    
    def create_mosaic(self) -> bool:
        """Create a complete mosaic from the processed images."""
        try:
            if not self.images:
                print("No images to process")
                return False
            
            print("Removing duplicate images...")
            unique_images = self.remove_duplicates()
            
            if len(unique_images) == 1:
                self.final_mosaic = unique_images[0]
                print("Only one unique image found, using it as the mosaic")
            else:
                print("Stitching unique images...")
                self.final_mosaic = self.stitch_images(unique_images)
            
            if self.final_mosaic is not None:
                # Save the mosaic
                output_path = os.path.join(self.output_dir, "farm_mosaic.jpg")
                cv2.imwrite(output_path, self.final_mosaic)
                print(f"Mosaic saved to: {output_path}")
                return True
            else:
                print("Failed to create mosaic")
                return False
                
        except Exception as e:
            print(f"Error creating mosaic: {e}")
            return False
    
    def enhance_image(self, image: np.ndarray) -> np.ndarray:
        """Apply basic image enhancement."""
        try:
            # Convert to LAB color space for better enhancement
            lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
            l, a, b = cv2.split(lab)
            
            # Apply CLAHE (Contrast Limited Adaptive Histogram Equalization)
            clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
            l = clahe.apply(l)
            
            # Merge channels and convert back to BGR
            enhanced = cv2.merge([l, a, b])
            enhanced = cv2.cvtColor(enhanced, cv2.COLOR_LAB2BGR)
            
            return enhanced
        except Exception as e:
            print(f"Error enhancing image: {e}")
            return image
    
    def get_image_info(self, image: np.ndarray) -> dict:
        """Get basic information about an image."""
        height, width = image.shape[:2]
        return {
            'width': width,
            'height': height,
            'channels': image.shape[2] if len(image.shape) == 3 else 1,
            'size_mb': (image.nbytes / (1024 * 1024))
        }


if GUI_AVAILABLE:
    class DroneImageProcessorGUI:
        """GUI interface for the drone image processor."""
        
        def __init__(self):
            self.processor = DroneImageProcessor()
            self.root = tk.Tk()
            self.root.title("Drone Image Processor - Farm Ground Mosaic")
            self.root.geometry("800x600")
            
            self.setup_ui()
        
        def setup_ui(self):
            """Set up the user interface."""
            # Main frame
            main_frame = ttk.Frame(self.root, padding="10")
            main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
            
            # Title
            title_label = ttk.Label(main_frame, text="Drone Image Processor", 
                                   font=("Arial", 16, "bold"))
            title_label.grid(row=0, column=0, columnspan=2, pady=(0, 20))
            
            # File selection frame
            file_frame = ttk.LabelFrame(main_frame, text="Image Selection", padding="10")
            file_frame.grid(row=1, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(0, 10))
            
            ttk.Button(file_frame, text="Select Images", 
                      command=self.select_images).grid(row=0, column=0, padx=(0, 10))
            
            self.image_count_label = ttk.Label(file_frame, text="No images selected")
            self.image_count_label.grid(row=0, column=1)
            
            # Processing options frame
            options_frame = ttk.LabelFrame(main_frame, text="Processing Options", padding="10")
            options_frame.grid(row=2, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(0, 10))
            
            self.enhance_var = tk.BooleanVar(value=True)
            ttk.Checkbutton(options_frame, text="Enhance images", 
                           variable=self.enhance_var).grid(row=0, column=0, sticky=tk.W)
            
            # Process button
            ttk.Button(main_frame, text="Process Images", 
                      command=self.process_images).grid(row=3, column=0, columnspan=2, pady=10)
            
            # Progress bar
            self.progress = ttk.Progressbar(main_frame, mode='indeterminate')
            self.progress.grid(row=4, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(0, 10))
            
            # Results frame
            results_frame = ttk.LabelFrame(main_frame, text="Results", padding="10")
            results_frame.grid(row=5, column=0, columnspan=2, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 10))
            
            self.results_text = tk.Text(results_frame, height=10, width=70)
            scrollbar = ttk.Scrollbar(results_frame, orient="vertical", command=self.results_text.yview)
            self.results_text.configure(yscrollcommand=scrollbar.set)
            
            self.results_text.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
            scrollbar.grid(row=0, column=1, sticky=(tk.N, tk.S))
            
            # Configure grid weights
            self.root.columnconfigure(0, weight=1)
            self.root.rowconfigure(0, weight=1)
            main_frame.columnconfigure(1, weight=1)
            main_frame.rowconfigure(5, weight=1)
            results_frame.columnconfigure(0, weight=1)
            results_frame.rowconfigure(0, weight=1)
        
        def select_images(self):
            """Open file dialog to select images."""
            filetypes = [
                ("Image files", "*.jpg *.jpeg *.png *.bmp *.tiff *.tif"),
                ("All files", "*.*")
            ]
            
            filenames = filedialog.askopenfilenames(
                title="Select drone images",
                filetypes=filetypes
            )
            
            if filenames:
                self.processor.images = []
                for filename in filenames:
                    img = cv2.imread(filename)
                    if img is not None:
                        self.processor.images.append(img)
                
                count = len(self.processor.images)
                self.image_count_label.config(text=f"{count} images selected")
                self.log_message(f"Loaded {count} images")
        
        def process_images(self):
            """Process the selected images."""
            if not self.processor.images:
                messagebox.showerror("Error", "Please select images first")
                return
            
            self.progress.start()
            self.log_message("Starting image processing...")
            
            try:
                # Enhance images if requested
                if self.enhance_var.get():
                    self.log_message("Enhancing images...")
                    enhanced_images = []
                    for i, img in enumerate(self.processor.images):
                        enhanced = self.processor.enhance_image(img)
                        enhanced_images.append(enhanced)
                        self.log_message(f"Enhanced image {i+1}")
                    self.processor.images = enhanced_images
                
                # Create mosaic
                self.log_message("Creating mosaic...")
                success = self.processor.create_mosaic()
                
                if success:
                    self.log_message("Mosaic created successfully!")
                    self.log_message(f"Output saved to: {self.processor.output_dir}/farm_mosaic.jpg")
                    
                    # Show image info
                    info = self.processor.get_image_info(self.processor.final_mosaic)
                    self.log_message(f"Mosaic dimensions: {info['width']}x{info['height']}")
                    self.log_message(f"Mosaic size: {info['size_mb']:.2f} MB")
                    
                    messagebox.showinfo("Success", "Mosaic created successfully!")
                else:
                    self.log_message("Failed to create mosaic")
                    messagebox.showerror("Error", "Failed to create mosaic")
                    
            except Exception as e:
                self.log_message(f"Error: {str(e)}")
                messagebox.showerror("Error", f"Processing failed: {str(e)}")
            finally:
                self.progress.stop()
        
        def log_message(self, message: str):
            """Add a message to the results text area."""
            self.results_text.insert(tk.END, f"{message}\n")
            self.results_text.see(tk.END)
            self.root.update()
        
        def run(self):
            """Start the GUI application."""
            self.root.mainloop()


def main():
    """Main function to run the application."""
    print("Drone Image Processor - Farm Ground Mosaic Creator")
    print("=" * 50)
    
    # Check if running in GUI mode or command line
    if len(sys.argv) > 1 and sys.argv[1] == "--gui":
        if GUI_AVAILABLE:
            app = DroneImageProcessorGUI()
            app.run()
        else:
            print("GUI not available - tkinter not installed")
            print("Please install tkinter or use command line mode")
    else:
        # Command line interface
        processor = DroneImageProcessor()
        
        print("Command line mode - provide image paths as arguments")
        print("Usage: python drone_processor.py image1.jpg image2.jpg ...")
        if GUI_AVAILABLE:
            print("Or use --gui flag for graphical interface")
        
        if len(sys.argv) > 1:
            image_paths = sys.argv[1:]
            if processor.load_images(image_paths):
                processor.create_mosaic()
            else:
                print("Failed to load images")


if __name__ == "__main__":
    main()
