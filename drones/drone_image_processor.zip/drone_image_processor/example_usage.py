#!/usr/bin/env python3
"""
Example script demonstrating how to use the DroneImageProcessor class programmatically.
"""

from drone_processor import DroneImageProcessor
import os
import glob

def example_usage():
    """Example of using the DroneImageProcessor class."""
    
    # Initialize the processor
    processor = DroneImageProcessor()
    
    # Example 1: Process images from a directory
    print("Example 1: Processing images from directory")
    image_directory = "sample_images"  # Change this to your image directory
    
    if os.path.exists(image_directory):
        # Get all image files from directory
        image_extensions = ['*.jpg', '*.jpeg', '*.png', '*.bmp', '*.tiff', '*.tif']
        image_paths = []
        
        for ext in image_extensions:
            image_paths.extend(glob.glob(os.path.join(image_directory, ext)))
            image_paths.extend(glob.glob(os.path.join(image_directory, ext.upper())))
        
        if image_paths:
            print(f"Found {len(image_paths)} images in {image_directory}")
            
            # Load and process images
            if processor.load_images(image_paths):
                # Enhance images
                print("Enhancing images...")
                enhanced_images = []
                for i, img in enumerate(processor.images):
                    enhanced = processor.enhance_image(img)
                    enhanced_images.append(enhanced)
                    print(f"Enhanced image {i+1}")
                
                processor.images = enhanced_images
                
                # Create mosaic
                success = processor.create_mosaic()
                
                if success:
                    print("Mosaic created successfully!")
                    info = processor.get_image_info(processor.final_mosaic)
                    print(f"Final mosaic: {info['width']}x{info['height']} pixels")
                    print(f"File size: {info['size_mb']:.2f} MB")
                else:
                    print("Failed to create mosaic")
            else:
                print("Failed to load images")
        else:
            print(f"No images found in {image_directory}")
    else:
        print(f"Directory {image_directory} does not exist")
    
    print("\n" + "="*50 + "\n")
    
    # Example 2: Process specific image files
    print("Example 2: Processing specific image files")
    specific_images = [
        "image1.jpg",
        "image2.jpg", 
        "image3.jpg"
    ]
    
    # Filter to only existing files
    existing_images = [img for img in specific_images if os.path.exists(img)]
    
    if existing_images:
        processor2 = DroneImageProcessor()
        if processor2.load_images(existing_images):
            success = processor2.create_mosaic()
            if success:
                print("Mosaic created successfully!")
            else:
                print("Failed to create mosaic")
    else:
        print("No specific images found - this is just an example")
    
    print("\n" + "="*50 + "\n")
    
    # Example 3: Batch processing with different settings
    print("Example 3: Batch processing with custom settings")
    
    # You can modify the processor settings
    processor3 = DroneImageProcessor()
    processor3.output_dir = "custom_output"  # Custom output directory
    
    # Create custom output directory
    if not os.path.exists(processor3.output_dir):
        os.makedirs(processor3.output_dir)
    
    print(f"Custom output directory: {processor3.output_dir}")
    print("This example shows how to customize the processor settings")

def create_sample_images():
    """Create some sample images for testing (requires matplotlib)."""
    try:
        import matplotlib.pyplot as plt
        import numpy as np
        
        print("Creating sample images for testing...")
        
        # Create sample_images directory
        if not os.path.exists("sample_images"):
            os.makedirs("sample_images")
        
        # Create 3 sample images with some overlap
        for i in range(3):
            # Create a simple pattern image
            img = np.zeros((400, 600, 3), dtype=np.uint8)
            
            # Add some colored rectangles
            colors = [(255, 0, 0), (0, 255, 0), (0, 0, 255)]  # RGB
            color = colors[i]
            
            # Create overlapping rectangles
            start_x = i * 200
            img[100:300, start_x:start_x+300] = color
            
            # Add some text
            plt.figure(figsize=(6, 4))
            plt.imshow(img)
            plt.title(f"Sample Farm Image {i+1}")
            plt.axis('off')
            plt.savefig(f"sample_images/sample_{i+1}.jpg", dpi=150, bbox_inches='tight')
            plt.close()
        
        print("Sample images created in 'sample_images' directory")
        print("You can now run the example with these test images")
        
    except ImportError:
        print("Matplotlib not available - cannot create sample images")
        print("Please provide your own drone images for testing")

if __name__ == "__main__":
    print("Drone Image Processor - Example Usage")
    print("=" * 50)
    
    # Create sample images if they don't exist
    if not os.path.exists("sample_images"):
        create_sample_images()
    
    # Run examples
    example_usage()
    
    print("\nTo run the GUI version, use:")
    print("python drone_processor.py --gui")
    
    print("\nTo process your own images from command line:")
    print("python drone_processor.py your_image1.jpg your_image2.jpg ...")
