#!/bin/bash

# Drone Image Processor - Quick Test Script
# Simple bash script to run basic tests

echo "🚁 Drone Image Processor - Quick Test Suite"
echo "============================================="
echo

# Check if required files exist
if [ ! -f "drone_processor.py" ]; then
    echo "❌ Error: drone_processor.py not found!"
    echo "Please run this script from the drone_image_processor directory."
    exit 1
fi

if [ ! -d "sample_images" ]; then
    echo "❌ Error: sample_images directory not found!"
    echo "Please run this script from the drone_image_processor directory."
    exit 1
fi

echo "✅ Required files found"
echo

# Test 1: Single Image Processing
echo "Test 1: Single Image Processing"
echo "Command: python drone_processor.py sample_images/sample_corn_field.jpg"
python drone_processor.py sample_images/sample_corn_field.jpg
echo

# Test 2: Duplicate Detection
echo "Test 2: Duplicate Detection (Lighting Variations)"
echo "Command: python drone_processor.py sample_images/sample_morning_lighting.jpg sample_images/sample_noon_lighting.jpg sample_images/sample_evening_lighting.jpg"
python drone_processor.py sample_images/sample_morning_lighting.jpg sample_images/sample_noon_lighting.jpg sample_images/sample_evening_lighting.jpg
echo

# Test 3: Overlap Stitching
echo "Test 3: Overlap Stitching (30% Overlap)"
echo "Command: python drone_processor.py sample_images/overlap_30_part_1.jpg sample_images/overlap_30_part_2.jpg sample_images/overlap_30_part_3.jpg sample_images/overlap_30_part_4.jpg"
python drone_processor.py sample_images/overlap_30_part_1.jpg sample_images/overlap_30_part_2.jpg sample_images/overlap_30_part_3.jpg sample_images/overlap_30_part_4.jpg
echo

# Test 4: Different Crop Types
echo "Test 4: Different Crop Types (Expected to fail stitching)"
echo "Command: python drone_processor.py sample_images/sample_rice_paddy.jpg sample_images/sample_vineyard.jpg sample_images/sample_orchard.jpg"
python drone_processor.py sample_images/sample_rice_paddy.jpg sample_images/sample_vineyard.jpg sample_images/sample_orchard.jpg
echo

# Test 5: Weather Conditions
echo "Test 5: Weather Conditions (Expected to fail stitching)"
echo "Command: python drone_processor.py sample_images/sample_rainy_weather.jpg sample_images/sample_foggy_weather.jpg sample_images/sample_dusty_weather.jpg"
python drone_processor.py sample_images/sample_rainy_weather.jpg sample_images/sample_foggy_weather.jpg sample_images/sample_dusty_weather.jpg
echo

echo "🎯 Quick Test Suite Complete!"
echo "For comprehensive testing, run: python run_tests.py"
echo "For detailed instructions, see: TESTING_INSTRUCTIONS.md"
