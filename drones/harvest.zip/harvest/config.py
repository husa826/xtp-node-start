"""
Configuration file for Harvest Measurement Program
"""

# Analysis Parameters
ANALYSIS_CONFIG = {
    # Color thresholds for crop detection (HSV)
    'green_thresholds': {
        'lower': [35, 40, 40],
        'upper': [85, 255, 255]
    },
    
    # NDVI calculation parameters
    'ndvi': {
        'threshold': 0.1,
        'min_value': -1.0,
        'max_value': 1.0
    },
    
    # Morphological operations
    'morphology': {
        'kernel_size': 5,
        'iterations': 1
    },
    
    # Yield estimation
    'yield': {
        'base_yield_per_m2': 2.5,  # kg/m²
        'pixel_area_m2': 0.0001,  # Assuming 1cm² per pixel
        'health_weight': 0.4,
        'coverage_weight': 0.3,
        'ndvi_weight': 0.3
    },
    
    # Health scoring
    'health_scoring': {
        'ndvi_weight': 0.5,
        'green_intensity_weight': 0.3,
        'coverage_weight': 0.2,
        'max_score': 100
    }
}

# UI Configuration
UI_CONFIG = {
    'page_title': 'Harvest Measurement Program',
    'page_icon': '🌾',
    'layout': 'wide',
    'theme': {
        'primary_color': '#1f77b4',
        'background_color': '#ffffff',
        'secondary_background_color': '#f0f2f6'
    }
}

# File Configuration
FILE_CONFIG = {
    'supported_formats': ['jpg', 'jpeg', 'png', 'tiff'],
    'max_file_size_mb': 50,
    'output_format': 'json'
}

# Crop Types (for future extension)
CROP_TYPES = {
    'wheat': {
        'base_yield_per_m2': 3.0,
        'optimal_ndvi': 0.7,
        'harvest_season': 'summer'
    },
    'corn': {
        'base_yield_per_m2': 4.5,
        'optimal_ndvi': 0.8,
        'harvest_season': 'fall'
    },
    'rice': {
        'base_yield_per_m2': 2.8,
        'optimal_ndvi': 0.6,
        'harvest_season': 'fall'
    },
    'soybean': {
        'base_yield_per_m2': 2.2,
        'optimal_ndvi': 0.7,
        'harvest_season': 'fall'
    }
}
