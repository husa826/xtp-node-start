import cv2
import numpy as np
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from PIL import Image
import io
from skimage import measure, segmentation, filters
from scipy import ndimage
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import json
from datetime import datetime
import os
from config import ANALYSIS_CONFIG, UI_CONFIG, FILE_CONFIG, CROP_TYPES

class HarvestMeasurementProcessor:
    """
    Advanced Harvest Measurement Processor for Drone Images
    Analyzes crop images to estimate harvest yield and health metrics
    """
    
    def __init__(self):
        self.results = {}
        self.image_data = None
        self.config = ANALYSIS_CONFIG
        
    def load_image(self, image_file):
        """Load and preprocess drone image"""
        try:
            # Read image
            image = Image.open(image_file)
            self.image_data = np.array(image)
            
            # Convert to RGB if needed
            if len(self.image_data.shape) == 3 and self.image_data.shape[2] == 4:
                self.image_data = cv2.cvtColor(self.image_data, cv2.COLOR_RGBA2RGB)
            elif len(self.image_data.shape) == 3 and self.image_data.shape[2] == 3:
                self.image_data = cv2.cvtColor(self.image_data, cv2.COLOR_BGR2RGB)
            
            return True
        except Exception as e:
            st.error(f"Error loading image: {str(e)}")
            return False
    
    def preprocess_image(self, image):
        """Preprocess image for analysis"""
        # Convert to different color spaces
        hsv = cv2.cvtColor(image, cv2.COLOR_RGB2HSV)
        lab = cv2.cvtColor(image, cv2.COLOR_RGB2LAB)
        gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
        
        # Apply Gaussian blur to reduce noise
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        
        return {
            'original': image,
            'hsv': hsv,
            'lab': lab,
            'gray': gray,
            'blurred': blurred
        }
    
    def detect_crop_areas(self, processed_image):
        """Detect crop areas using multiple methods"""
        gray = processed_image['gray']
        hsv = processed_image['hsv']
        
        # Method 1: Green vegetation detection using HSV
        lower_green = np.array(self.config['green_thresholds']['lower'])
        upper_green = np.array(self.config['green_thresholds']['upper'])
        green_mask = cv2.inRange(hsv, lower_green, upper_green)
        
        # Method 2: NDVI-like calculation (simplified)
        r, g, b = cv2.split(processed_image['original'])
        ndvi_like = (g.astype(float) - r.astype(float)) / (g.astype(float) + r.astype(float) + 1e-6)
        ndvi_mask = (ndvi_like > self.config['ndvi']['threshold']).astype(np.uint8) * 255
        
        # Method 3: Edge detection
        edges = cv2.Canny(gray, 50, 150)
        
        # Combine methods
        combined_mask = cv2.bitwise_or(green_mask, ndvi_mask)
        
        # Morphological operations to clean up
        kernel_size = self.config['morphology']['kernel_size']
        kernel = np.ones((kernel_size, kernel_size), np.uint8)
        combined_mask = cv2.morphologyEx(combined_mask, cv2.MORPH_CLOSE, kernel)
        combined_mask = cv2.morphologyEx(combined_mask, cv2.MORPH_OPEN, kernel)
        
        return {
            'green_mask': green_mask,
            'ndvi_mask': ndvi_mask,
            'combined_mask': combined_mask,
            'edges': edges,
            'ndvi_values': ndvi_like
        }
    
    def analyze_crop_health(self, processed_image, crop_masks):
        """Analyze crop health metrics"""
        original = processed_image['original']
        green_mask = crop_masks['green_mask']
        ndvi_values = crop_masks['ndvi_values']
        
        # Calculate health metrics
        total_pixels = original.shape[0] * original.shape[1]
        crop_pixels = np.sum(green_mask > 0)
        crop_coverage = (crop_pixels / total_pixels) * 100
        
        # Calculate average NDVI
        valid_ndvi = ndvi_values[green_mask > 0]
        avg_ndvi = np.mean(valid_ndvi) if len(valid_ndvi) > 0 else 0
        
        # Color analysis for health assessment
        crop_area = original[green_mask > 0]
        if len(crop_area) > 0:
            avg_green_intensity = np.mean(crop_area[:, 1])  # Green channel
            color_variance = np.var(crop_area, axis=0)
        else:
            avg_green_intensity = 0
            color_variance = np.array([0, 0, 0])
        
        # Health score calculation using config weights
        health_config = self.config['health_scoring']
        ndvi_score = min(100, max(0, avg_ndvi * 100))
        green_score = min(100, max(0, avg_green_intensity / 2.55))
        coverage_score = min(100, max(0, crop_coverage))
        
        health_score = (
            ndvi_score * health_config['ndvi_weight'] +
            green_score * health_config['green_intensity_weight'] +
            coverage_score * health_config['coverage_weight']
        )
        
        return {
            'crop_coverage': crop_coverage,
            'avg_ndvi': avg_ndvi,
            'avg_green_intensity': avg_green_intensity,
            'color_variance': color_variance,
            'health_score': health_score,
            'crop_pixels': crop_pixels,
            'total_pixels': total_pixels
        }
    
    def estimate_yield(self, health_metrics, image_area_m2=None, crop_type='wheat'):
        """Estimate harvest yield based on health metrics"""
        # Get crop-specific parameters
        crop_params = CROP_TYPES.get(crop_type, CROP_TYPES['wheat'])
        base_yield_per_m2 = crop_params['base_yield_per_m2']
        
        # Adjust based on health metrics using config weights
        yield_config = self.config['yield']
        health_factor = health_metrics['health_score'] / 100
        coverage_factor = health_metrics['crop_coverage'] / 100
        ndvi_factor = min(1.5, max(0.5, health_metrics['avg_ndvi'] * 2))
        
        # Calculate yield
        if image_area_m2:
            estimated_yield = image_area_m2 * base_yield_per_m2 * health_factor * coverage_factor * ndvi_factor
        else:
            # Estimate area based on pixel count
            estimated_area = health_metrics['crop_pixels'] * yield_config['pixel_area_m2']
            estimated_yield = estimated_area * base_yield_per_m2 * health_factor * coverage_factor * ndvi_factor
        
        return {
            'estimated_yield_kg': estimated_yield,
            'estimated_area_m2': image_area_m2 or (health_metrics['crop_pixels'] * yield_config['pixel_area_m2']),
            'yield_per_m2': estimated_yield / (image_area_m2 or (health_metrics['crop_pixels'] * yield_config['pixel_area_m2'])),
            'health_factor': health_factor,
            'coverage_factor': coverage_factor,
            'ndvi_factor': ndvi_factor,
            'crop_type': crop_type,
            'base_yield_per_m2': base_yield_per_m2
        }
    
    def generate_report(self, health_metrics, yield_estimate):
        """Generate comprehensive analysis report"""
        report = {
            'timestamp': datetime.now().isoformat(),
            'crop_health': {
                'health_score': round(health_metrics['health_score'], 2),
                'crop_coverage_percent': round(health_metrics['crop_coverage'], 2),
                'average_ndvi': round(health_metrics['avg_ndvi'], 3),
                'average_green_intensity': round(health_metrics['avg_green_intensity'], 2)
            },
            'yield_estimation': {
                'estimated_yield_kg': round(yield_estimate['estimated_yield_kg'], 2),
                'estimated_area_m2': round(yield_estimate['estimated_area_m2'], 2),
                'yield_per_m2_kg': round(yield_estimate['yield_per_m2'], 2),
                'health_factor': round(yield_estimate['health_factor'], 2),
                'coverage_factor': round(yield_estimate['coverage_factor'], 2),
                'ndvi_factor': round(yield_estimate['ndvi_factor'], 2),
                'crop_type': yield_estimate['crop_type'],
                'base_yield_per_m2': yield_estimate['base_yield_per_m2']
            },
            'recommendations': self._generate_recommendations(health_metrics, yield_estimate)
        }
        
        return report
    
    def _generate_recommendations(self, health_metrics, yield_estimate):
        """Generate farming recommendations based on analysis"""
        recommendations = []
        
        if health_metrics['health_score'] < 60:
            recommendations.append("⚠️ Low health score detected. Consider soil testing and nutrient analysis.")
        
        if health_metrics['crop_coverage'] < 70:
            recommendations.append("�� Low crop coverage. Check for bare spots and consider reseeding.")
        
        if health_metrics['avg_ndvi'] < 0.3:
            recommendations.append("🌱 Low vegetation index. Consider irrigation and fertilization.")
        
        if yield_estimate['yield_per_m2'] < 1.5:
            recommendations.append("📉 Below average yield potential. Review farming practices.")
        
        if not recommendations:
            recommendations.append("✅ Crop appears healthy with good yield potential!")
        
        return recommendations

def main():
    """Main Streamlit application"""
    st.set_page_config(
        page_title=UI_CONFIG['page_title'],
        page_icon=UI_CONFIG['page_icon'],
        layout=UI_CONFIG['layout']
    )
    
    st.title("🌾 Harvest Measurement Program")
    st.markdown("**Advanced Drone Image Analysis for Crop Yield Estimation**")
    
    # Initialize processor
    if 'processor' not in st.session_state:
        st.session_state.processor = HarvestMeasurementProcessor()
    
    # Sidebar for controls
    st.sidebar.header("📊 Analysis Controls")
    
    # Sample images section
    st.sidebar.subheader("🖼️ Sample Images")
    use_sample = st.sidebar.checkbox("Use Sample Image", help="Try the analysis with pre-loaded sample images")
    
    sample_image_path = None
    if use_sample:
        # Get list of sample images
        sample_dir = "sample_images"
        if os.path.exists(sample_dir):
            sample_files = [f for f in os.listdir(sample_dir) if f.endswith(('.jpg', '.jpeg', '.png'))]
            if sample_files:
                sample_files.sort()
                selected_sample = st.sidebar.selectbox(
                    "Select Sample Image",
                    options=sample_files,
                    help="Choose from available sample crop field images"
                )
                sample_image_path = os.path.join(sample_dir, selected_sample)
                
                # Display sample image info
                if selected_sample:
                    parts = selected_sample.replace('.jpg', '').split('_')
                    if len(parts) >= 2:
                        crop_type = parts[0]
                        health_level = parts[1]
                        st.sidebar.info(f"**Sample:** {crop_type.title()} - {health_level.title()} Health")
            else:
                st.sidebar.warning("No sample images found!")
        else:
            st.sidebar.warning("Sample images directory not found!")
    
    # Image upload
    uploaded_file = st.sidebar.file_uploader(
        "Upload Drone Image",
        type=FILE_CONFIG['supported_formats'],
        help="Upload a high-resolution drone image of your crop field",
        disabled=use_sample
    )
    
    # Analysis parameters
    st.sidebar.subheader("🔧 Parameters")
    image_area = st.sidebar.number_input(
        "Field Area (m²)",
        min_value=0.0,
        value=1000.0,
        step=100.0,
        help="Enter the actual area of the field in square meters for accurate yield estimation"
    )
    
    # Crop type selection
    crop_type = st.sidebar.selectbox(
        "Crop Type",
        options=list(CROP_TYPES.keys()),
        index=0,
        help="Select the crop type for accurate yield estimation"
    )
    
    # Process button
    analyze_button = st.sidebar.button("🚀 Analyze Image", type="primary")
    
    if (uploaded_file is not None or sample_image_path is not None) and analyze_button:
        with st.spinner("Processing image..."):
            # Determine which image to use
            if use_sample and sample_image_path:
                # Load sample image
                if st.session_state.processor.load_image(sample_image_path):
                    image_source = "sample"
                else:
                    st.error("Failed to load sample image!")
                    image_source = None
            elif uploaded_file is not None:
                # Load uploaded image
                if st.session_state.processor.load_image(uploaded_file):
                    image_source = "uploaded"
                else:
                    st.error("Failed to load uploaded image!")
                    image_source = None
            else:
                image_source = None
            
            if image_source:
                # Preprocess
                processed = st.session_state.processor.preprocess_image(st.session_state.processor.image_data)
                
                # Detect crop areas
                crop_masks = st.session_state.processor.detect_crop_areas(processed)
                
                # Analyze health
                health_metrics = st.session_state.processor.analyze_crop_health(processed, crop_masks)
                
                # Estimate yield
                yield_estimate = st.session_state.processor.estimate_yield(health_metrics, image_area, crop_type)
                
                # Generate report
                report = st.session_state.processor.generate_report(health_metrics, yield_estimate)
                
                # Add image source info to report
                report['image_source'] = image_source
                if image_source == "sample":
                    report['sample_image_path'] = sample_image_path
                
                # Store results
                st.session_state.results = {
                    'processed': processed,
                    'crop_masks': crop_masks,
                    'health_metrics': health_metrics,
                    'yield_estimate': yield_estimate,
                    'report': report,
                    'image_source': image_source
                }
    
    # Display results
    if 'results' in st.session_state:
        results = st.session_state.results
        
        # Main metrics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric(
                "Health Score",
                f"{results['health_metrics']['health_score']:.1f}/100",
                delta=f"{results['health_metrics']['health_score'] - 70:.1f}"
            )
        
        with col2:
            st.metric(
                "Crop Coverage",
                f"{results['health_metrics']['crop_coverage']:.1f}%",
                delta=f"{results['health_metrics']['crop_coverage'] - 80:.1f}%"
            )
        
        with col3:
            st.metric(
                "Estimated Yield",
                f"{results['yield_estimate']['estimated_yield_kg']:.1f} kg",
                delta=f"{results['yield_estimate']['yield_per_m2']:.2f} kg/m²"
            )
        
        with col4:
            st.metric(
                "NDVI Index",
                f"{results['health_metrics']['avg_ndvi']:.3f}",
                delta=f"{results['health_metrics']['avg_ndvi'] - 0.5:.3f}"
            )
        
        # Visualizations
        st.subheader("📈 Analysis Visualizations")
        
        # Create tabs for different views
        tab1, tab2, tab3, tab4 = st.tabs(["Original & Masks", "Health Analysis", "Yield Estimation", "Detailed Report"])
        
        with tab1:
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader("Original Image")
                st.image(results['processed']['original'], use_column_width=True)
            
            with col2:
                st.subheader("Crop Detection")
                st.image(results['crop_masks']['combined_mask'], use_column_width=True)
        
        with tab2:
            # Health score visualization
            fig = make_subplots(
                rows=2, cols=2,
                subplot_titles=('Health Score', 'Crop Coverage', 'NDVI Distribution', 'Color Analysis'),
                specs=[[{"type": "indicator"}, {"type": "indicator"}],
                       [{"type": "histogram"}, {"type": "bar"}]]
            )
            
            # Health score gauge
            fig.add_trace(go.Indicator(
                mode="gauge+number+delta",
                value=results['health_metrics']['health_score'],
                domain={'x': [0, 1], 'y': [0, 1]},
                title={'text': "Health Score"},
                gauge={'axis': {'range': [None, 100]},
                       'bar': {'color': "darkblue"},
                       'steps': [{'range': [0, 50], 'color': "lightgray"},
                                {'range': [50, 80], 'color': "yellow"},
                                {'range': [80, 100], 'color': "green"}],
                       'threshold': {'line': {'color': "red", 'width': 4},
                                   'thickness': 0.75, 'value': 90}}
            ), row=1, col=1)
            
            # Coverage gauge
            fig.add_trace(go.Indicator(
                mode="gauge+number",
                value=results['health_metrics']['crop_coverage'],
                domain={'x': [0, 1], 'y': [0, 1]},
                title={'text': "Crop Coverage %"},
                gauge={'axis': {'range': [None, 100]},
                       'bar': {'color': "darkgreen"},
                       'steps': [{'range': [0, 50], 'color': "lightgray"},
                                {'range': [50, 80], 'color': "yellow"},
                                {'range': [80, 100], 'color': "green"}]}
            ), row=1, col=2)
            
            # NDVI histogram
            ndvi_flat = results['crop_masks']['ndvi_values'].flatten()
            fig.add_trace(go.Histogram(x=ndvi_flat, nbinsx=30, name="NDVI Distribution"), row=2, col=1)
            
            # Color variance bar chart
            colors = ['Red', 'Green', 'Blue']
            variances = results['health_metrics']['color_variance']
            fig.add_trace(go.Bar(x=colors, y=variances, name="Color Variance"), row=2, col=2)
            
            fig.update_layout(height=600, showlegend=False)
            st.plotly_chart(fig, use_container_width=True)
        
        with tab3:
            # Yield estimation visualization
            yield_data = results['yield_estimate']
            
            col1, col2 = st.columns(2)
            
            with col1:
                # Yield factors pie chart
                factors = ['Health', 'Coverage', 'NDVI']
                values = [yield_data['health_factor'], yield_data['coverage_factor'], yield_data['ndvi_factor']]
                
                fig_pie = px.pie(values=values, names=factors, title="Yield Estimation Factors")
                st.plotly_chart(fig_pie, use_container_width=True)
            
            with col2:
                # Yield metrics
                metrics_data = {
                    'Metric': ['Estimated Yield (kg)', 'Area (m²)', 'Yield per m² (kg)'],
                    'Value': [yield_data['estimated_yield_kg'], yield_data['estimated_area_m2'], yield_data['yield_per_m2']]
                }
                
                fig_bar = px.bar(metrics_data, x='Metric', y='Value', title="Yield Metrics")
                st.plotly_chart(fig_bar, use_container_width=True)
        
        with tab4:
            # Detailed report
            st.subheader("📋 Detailed Analysis Report")
            
            # Health metrics
            st.subheader("🌱 Crop Health Metrics")
            health_data = results['report']['crop_health']
            for key, value in health_data.items():
                st.write(f"**{key.replace('_', ' ').title()}:** {value}")
            
            # Yield estimation
            st.subheader("📊 Yield Estimation")
            yield_data = results['report']['yield_estimation']
            for key, value in yield_data.items():
                st.write(f"**{key.replace('_', ' ').title()}:** {value}")
            
            # Recommendations
            st.subheader("�� Recommendations")
            for i, rec in enumerate(results['report']['recommendations'], 1):
                st.write(f"{i}. {rec}")
            
            # Download report
            report_json = json.dumps(results['report'], indent=2)
            st.download_button(
                label="📥 Download Report (JSON)",
                data=report_json,
                file_name=f"harvest_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                mime="application/json"
            )
            
            # Save to output directory
            if st.button("💾 Save Analysis to Output Directory"):
                try:
                    # Ensure output directory exists
                    os.makedirs('output', exist_ok=True)
                    
                    # Generate filename
                    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                    image_source = results.get('image_source', 'unknown')
                    filename = f"output/harvest_analysis_{timestamp}_{image_source}.json"
                    
                    # Save report
                    with open(filename, 'w') as f:
                        json.dump(results['report'], f, indent=2)
                    
                    st.success(f"✅ Analysis saved to: {filename}")
                    
                    # Also save a summary CSV
                    csv_filename = f"output/harvest_summary_{timestamp}_{image_source}.csv"
                    summary_data = {
                        'timestamp': [results['report']['timestamp']],
                        'crop_type': [results['report']['yield_estimation']['crop_type']],
                        'health_score': [results['report']['crop_health']['health_score']],
                        'crop_coverage_percent': [results['report']['crop_health']['crop_coverage_percent']],
                        'avg_ndvi': [results['report']['crop_health']['average_ndvi']],
                        'estimated_yield_kg': [results['report']['yield_estimation']['estimated_yield_kg']],
                        'yield_per_m2_kg': [results['report']['yield_estimation']['yield_per_m2_kg']],
                        'field_area_m2': [results['report']['yield_estimation']['estimated_area_m2']],
                        'image_source': [image_source]
                    }
                    
                    df = pd.DataFrame(summary_data)
                    df.to_csv(csv_filename, index=False)
                    st.success(f"✅ Summary saved to: {csv_filename}")
                    
                except Exception as e:
                    st.error(f"❌ Error saving analysis: {e}")
    
    else:
        # Welcome screen
        st.markdown("""
        ## Welcome to the Harvest Measurement Program! 🌾
        
        This advanced tool analyzes drone images to provide:
        
        - **Crop Health Assessment**: NDVI analysis, color metrics, and health scoring
        - **Yield Estimation**: Predictive yield calculations based on multiple factors
        - **Coverage Analysis**: Crop density and coverage percentage
        - **Visual Analytics**: Interactive charts and visualizations
        - **Detailed Reports**: Comprehensive analysis with recommendations
        
        ### How to Use:
        1. Upload a high-resolution drone image of your crop field
        2. Enter the field area in square meters (optional but recommended)
        3. Select the crop type for accurate estimation
        4. Click "Analyze Image" to process
        5. View results in the interactive dashboard
        
        ### Supported Image Formats:
        - JPG/JPEG
        - PNG
        - TIFF
        
        ### Tips for Best Results:
        - Use images taken during optimal lighting conditions
        - Ensure good contrast between crops and soil
        - Higher resolution images provide more accurate results
        - Images should cover the entire field area
        """)
        
        # Sample image analysis
        st.subheader("🖼️ Sample Analysis")
        
        # Display sample images gallery
        sample_dir = "sample_images"
        if os.path.exists(sample_dir):
            sample_files = [f for f in os.listdir(sample_dir) if f.endswith(('.jpg', '.jpeg', '.png'))]
            if sample_files:
                st.info("**Try the analysis with these sample images:**")
                
                # Group images by crop type
                crop_groups = {}
                for file in sample_files:
                    crop_type = file.split('_')[0]
                    if crop_type not in crop_groups:
                        crop_groups[crop_type] = []
                    crop_groups[crop_type].append(file)
                
                # Display images in columns
                for crop_type, files in crop_groups.items():
                    st.write(f"**{crop_type.title()} Fields:**")
                    cols = st.columns(min(len(files), 4))
                    for i, file in enumerate(files[:4]):  # Show max 4 per crop type
                        with cols[i]:
                            image_path = os.path.join(sample_dir, file)
                            try:
                                image = Image.open(image_path)
                                st.image(image, caption=file.replace('.jpg', '').replace('_', ' ').title(), use_column_width=True)
                            except Exception as e:
                                st.error(f"Error loading {file}: {e}")
                
                st.info("💡 **Tip:** Check 'Use Sample Image' in the sidebar to analyze these images!")
            else:
                st.info("No sample images available. Upload an image to see the analysis in action!")
        else:
            st.info("Upload an image to see the analysis in action!")

if __name__ == "__main__":
    main()
