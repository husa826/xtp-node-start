# 🌾 Harvest Measurement Program

An advanced drone image analysis tool for crop yield estimation and health assessment.

## Features

- **Crop Health Analysis**: NDVI calculation, color metrics, and health scoring
- **Yield Estimation**: Predictive yield calculations based on multiple factors
- **Coverage Analysis**: Crop density and coverage percentage
- **Interactive Dashboard**: Real-time visualizations and analytics
- **Detailed Reports**: Comprehensive analysis with farming recommendations
- **Multiple Crop Types**: Support for wheat, corn, rice, and soybean
- **Configurable Parameters**: Customizable analysis settings
- **Sample Images**: Pre-loaded sample images for testing and demonstration
- **Output Management**: Save analysis results to local directories
- **Sample Analysis**: Try the tool with built-in sample crop field images

## Installation

### Quick Setup (Recommended)
Use the automated setup script:
```bash
cd /Users/administrator/Workspace/drones/harvest
chmod +x setup.sh
./setup.sh
```

### Manual Setup
1. Navigate to the project directory:
   ```bash
   cd /Users/administrator/Workspace/drones/harvest
   ```

2. Create and activate virtual environment:
   ```bash
   python3 -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install required dependencies:
   ```bash
   pip install --upgrade pip
   pip install setuptools wheel
   pip install -r requirements.txt
   ```

### Virtual Environment Management
- **Activate**: `source venv/bin/activate`
- **Deactivate**: `deactivate`
- **Reinstall**: Delete `venv` folder and run setup again

## Usage

### Quick Start
```bash
# Activate virtual environment
source venv/bin/activate

# Run the application
python run_app.py
```

### Manual Start
```bash
# Activate virtual environment
source venv/bin/activate

# Run with Streamlit directly
streamlit run harvest_measurement.py
```

### Important Notes
- **Always activate the virtual environment** before running the application
- The virtual environment must be activated in each new terminal session
- If you see import errors, ensure the virtual environment is activated

### Using the Application

1. **Choose Image Source**: 
   - Upload your own high-resolution drone image, OR
   - Use pre-loaded sample images for testing
2. **Set Parameters**: 
   - Enter the field area in square meters (optional but recommended)
   - Select the crop type for accurate estimation
3. **Analyze**: Click "Analyze Image" to process
4. **View Results**: Explore the interactive dashboard with:
   - Health metrics and scores
   - Yield estimations
   - Visual analysis charts
   - Detailed reports and recommendations
5. **Save Results**: Download reports or save to local output directory

## Supported Image Formats

- JPG/JPEG
- PNG
- TIFF

## Analysis Methods

### Crop Detection
- **Green Vegetation Detection**: HSV color space analysis
- **NDVI-like Calculation**: Simplified vegetation index
- **Edge Detection**: Boundary identification
- **Morphological Operations**: Noise reduction and cleanup

### Health Metrics
- **Health Score**: 0-100 scale based on multiple factors
- **Crop Coverage**: Percentage of field covered by crops
- **NDVI Index**: Vegetation health indicator
- **Color Analysis**: RGB channel variance analysis

### Yield Estimation
- **Crop-Specific Factors**: Different base yields for different crops
- **Health Adjustment**: Based on crop health score
- **Coverage Adjustment**: Based on crop density
- **NDVI Adjustment**: Based on vegetation index

## Supported Crop Types

- **Wheat**: Base yield 3.0 kg/m², optimal NDVI 0.7
- **Corn**: Base yield 4.5 kg/m², optimal NDVI 0.8
- **Rice**: Base yield 2.8 kg/m², optimal NDVI 0.6
- **Soybean**: Base yield 2.2 kg/m², optimal NDVI 0.7

## Technical Details

### Dependencies
- **OpenCV**: Image processing and computer vision
- **NumPy**: Numerical computations
- **Streamlit**: Web application framework
- **Plotly**: Interactive visualizations
- **scikit-image**: Advanced image analysis
- **Pandas**: Data manipulation
- **Matplotlib**: Static plotting

### Architecture
- **Modular Design**: Separate classes for different analysis components
- **Configuration-Driven**: Easy parameter adjustment via config file
- **Real-time Processing**: Immediate results and visualizations
- **Extensible**: Easy to add new analysis methods and crop types

## Sample Images and Outputs

### Sample Images
The project includes 20 pre-generated sample crop field images for testing and demonstration:

- **Crop Types**: Wheat, Corn, Rice, Soybean
- **Health Levels**: Poor, Fair, Good, Excellent
- **Mixed Scenarios**: Fields with varying health conditions
- **Location**: `sample_images/` directory

#### Sample Image Naming Convention
- `{crop_type}_{health_level}_field.jpg`
- Example: `wheat_good_field.jpg`, `corn_excellent_field.jpg`

### Sample Analysis Outputs
Pre-generated analysis reports are available for reference:

- **Location**: `output/sample_reports/` directory
- **Format**: JSON files with comprehensive analysis data
- **Coverage**: All crop types and health levels
- **Field Sizes**: Various field areas (500m² to 5000m²)

#### Sample Report Structure
```json
{
  "timestamp": "2024-01-15T10:30:00",
  "analysis_id": "analysis_20240115_103000_wheat_good",
  "image_info": {
    "filename": "wheat_good_field.jpg",
    "crop_type": "wheat",
    "field_area_m2": 1000
  },
  "crop_health": {
    "health_score": 78.5,
    "crop_coverage_percent": 82.3,
    "average_ndvi": 0.65
  },
  "yield_estimation": {
    "estimated_yield_kg": 2456.7,
    "yield_per_m2_kg": 2.46
  },
  "recommendations": ["✅ Crop appears healthy with good yield potential!"]
}
```

### Output Management
The application provides multiple ways to save and manage analysis results:

1. **Download Reports**: Direct download of JSON reports
2. **Local Storage**: Save to `output/` directory
3. **CSV Summaries**: Export key metrics to CSV format
4. **Batch Processing**: Analyze multiple images and save results

#### Output Directory Structure
```
output/
├── sample_reports/          # Pre-generated sample reports
├── harvest_analysis_*.json  # Individual analysis reports
├── harvest_summary_*.csv    # Summary CSV files
└── sample_data_summary.json # Overview of all sample data
```

## Customization

### Adding New Crop Types
Edit `config.py` to add new crop types:
```python
CROP_TYPES = {
    'new_crop': {
        'base_yield_per_m2': 2.5,
        'optimal_ndvi': 0.6,
        'harvest_season': 'summer'
    }
}
```

### Adjusting Analysis Parameters
Modify `ANALYSIS_CONFIG` in `config.py`:
- Color thresholds for crop detection
- NDVI calculation parameters
- Yield estimation weights
- Health scoring factors

### Adding New Analysis Methods
Extend the `HarvestMeasurementProcessor` class with new methods for:
- Different crop types
- Additional health metrics
- Custom yield calculations

## Troubleshooting

### Virtual Environment Issues
1. **Import Errors**: Ensure virtual environment is activated (`source venv/bin/activate`)
2. **Package Not Found**: Reinstall requirements (`pip install -r requirements.txt`)
3. **Permission Errors**: Make setup script executable (`chmod +x setup.sh`)
4. **Python Version**: Ensure Python 3.8+ is installed (`python3 --version`)

### Application Issues
1. **Image Loading Errors**: Ensure image format is supported (JPG, PNG, TIFF)
2. **Low Analysis Quality**: Use higher resolution images
3. **Inaccurate Results**: Verify field area input and crop type selection
4. **Performance Issues**: Reduce image size for faster processing
5. **Testing the Tool**: Use sample images to verify functionality before uploading your own images

### Performance Tips
- Use images under 10MB for optimal performance
- Ensure good lighting conditions in source images
- Process images during optimal crop growth stages
- Use appropriate crop type selection for accurate yield estimation

## Contributing

Feel free to contribute by:
- Adding new analysis methods
- Improving accuracy algorithms
- Enhancing the user interface
- Adding support for new image formats
- Adding new crop types

## License

This project is open source and available under the MIT License.

## Support

For issues or questions, please create an issue in the project repository.
