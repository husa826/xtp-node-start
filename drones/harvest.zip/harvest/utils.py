"""
Utility functions for Harvest Measurement Program
"""

import cv2
import numpy as np
from PIL import Image
import json
from datetime import datetime
import pandas as pd

def validate_image(image_file):
    """
    Validate uploaded image file
    """
    try:
        # Check file size (max 50MB)
        image_file.seek(0, 2)  # Seek to end
        file_size = image_file.tell()
        image_file.seek(0)  # Reset to beginning
        
        if file_size > 50 * 1024 * 1024:  # 50MB
            return False, "File size too large (max 50MB)"
        
        # Try to open image
        image = Image.open(image_file)
        image_file.seek(0)  # Reset to beginning
        
        # Check dimensions
        width, height = image.size
        if width < 100 or height < 100:
            return False, "Image too small (min 100x100 pixels)"
        
        return True, "Valid image"
        
    except Exception as e:
        return False, f"Invalid image: {str(e)}"

def resize_image_if_needed(image, max_size=2048):
    """
    Resize image if it's too large for processing
    """
    height, width = image.shape[:2]
    
    if max(height, width) > max_size:
        # Calculate scaling factor
        scale = max_size / max(height, width)
        new_width = int(width * scale)
        new_height = int(height * scale)
        
        # Resize image
        resized = cv2.resize(image, (new_width, new_height), interpolation=cv2.INTER_AREA)
        return resized, scale
    
    return image, 1.0

def calculate_image_statistics(image):
    """
    Calculate basic image statistics
    """
    stats = {
        'dimensions': image.shape[:2],
        'channels': image.shape[2] if len(image.shape) == 3 else 1,
        'mean_brightness': np.mean(image),
        'std_brightness': np.std(image),
        'min_value': np.min(image),
        'max_value': np.max(image)
    }
    
    if len(image.shape) == 3:
        # Color statistics
        for i, color in enumerate(['red', 'green', 'blue']):
            channel = image[:, :, i]
            stats[f'{color}_mean'] = np.mean(channel)
            stats[f'{color}_std'] = np.std(channel)
    
    return stats

def export_results_to_csv(results, filename=None):
    """
    Export analysis results to CSV format
    """
    if filename is None:
        filename = f"harvest_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    
    # Flatten results for CSV
    flat_data = {}
    
    # Health metrics
    for key, value in results['health_metrics'].items():
        flat_data[f'health_{key}'] = value
    
    # Yield estimation
    for key, value in results['yield_estimate'].items():
        flat_data[f'yield_{key}'] = value
    
    # Create DataFrame and save
    df = pd.DataFrame([flat_data])
    df.to_csv(filename, index=False)
    
    return filename

def create_analysis_summary(results):
    """
    Create a human-readable summary of analysis results
    """
    health = results['health_metrics']
    yield_data = results['yield_estimate']
    
    summary = f"""
HARVEST MEASUREMENT ANALYSIS SUMMARY
=====================================

CROP HEALTH:
- Health Score: {health['health_score']:.1f}/100
- Crop Coverage: {health['crop_coverage']:.1f}%
- Average NDVI: {health['avg_ndvi']:.3f}
- Green Intensity: {health['avg_green_intensity']:.1f}

YIELD ESTIMATION:
- Estimated Yield: {yield_data['estimated_yield_kg']:.1f} kg
- Field Area: {yield_data['estimated_area_m2']:.1f} m²
- Yield per m²: {yield_data['yield_per_m2']:.2f} kg/m²
- Crop Type: {yield_data['crop_type']}

FACTORS:
- Health Factor: {yield_data['health_factor']:.2f}
- Coverage Factor: {yield_data['coverage_factor']:.2f}
- NDVI Factor: {yield_data['ndvi_factor']:.2f}

Analysis completed on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""
    
    return summary
```

```python:/Users/administrator/Workspace/drones/test_harvest.py
"""
Test script for Harvest Measurement Program
"""

import cv2
import numpy as np
from harvest_measurement import HarvestMeasurementProcessor
import matplotlib.pyplot as plt

def create_test_image():
    """
    Create a synthetic test image for testing
    """
    # Create a 500x500 image
    image = np.zeros((500, 500, 3), dtype=np.uint8)
    
    # Add soil background (brown)
    image[:, :] = [139, 69, 19]
    
    # Add crop areas (green)
    # Healthy crop area
    cv2.rectangle(image, (50, 50), (200, 200), (34, 139, 34), -1)
    
    # Less healthy crop area
    cv2.rectangle(image, (250, 50), (400, 200), (107, 142, 35), -1)
    
    # Bare soil area
    cv2.rectangle(image, (50, 250), (200, 400), (160, 82, 45), -1)
    
    # Mixed area
    cv2.rectangle(image, (250, 250), (400, 400), (85, 107, 47), -1)
    
    return image

def test_processor():
    """
    Test the HarvestMeasurementProcessor
    """
    print("🧪 Testing Harvest Measurement Processor...")
    
    # Create processor
    processor = HarvestMeasurementProcessor()
    
    # Create test image
    test_image = create_test_image()
    
    # Test preprocessing
    print("Testing image preprocessing...")
    processed = processor.preprocess_image(test_image)
    print(f"✅ Preprocessing completed. Image shape: {processed['original'].shape}")
    
    # Test crop detection
    print("Testing crop detection...")
    crop_masks = processor.detect_crop_areas(processed)
    print(f"✅ Crop detection completed. Found {np.sum(crop_masks['combined_mask'] > 0)} crop pixels")
    
    # Test health analysis
    print("Testing health analysis...")
    health_metrics = processor.analyze_crop_health(processed, crop_masks)
    print(f"✅ Health analysis completed. Health score: {health_metrics['health_score']:.1f}")
    
    # Test yield estimation
    print("Testing yield estimation...")
    yield_estimate = processor.estimate_yield(health_metrics, 1000, 'wheat')
    print(f"✅ Yield estimation completed. Estimated yield: {yield_estimate['estimated_yield_kg']:.1f} kg")
    
    # Test report generation
    print("Testing report generation...")
    report = processor.generate_report(health_metrics, yield_estimate)
    print(f"✅ Report generation completed. Generated {len(report['recommendations'])} recommendations")
    
    print("\n🎉 All tests passed successfully!")
    
    return {
        'processed': processed,
        'crop_masks': crop_masks,
        'health_metrics': health_metrics,
        'yield_estimate': yield_estimate,
        'report': report
    }

def visualize_test_results(results):
    """
    Visualize test results
    """
    fig, axes = plt.subplots(2, 3, figsize=(15, 10))
    
    # Original image
    axes[0, 0].imshow(results['processed']['original'])
    axes[0, 0].set_title('Original Test Image')
    axes[0, 0].axis('off')
    
    # Green mask
    axes[0, 1].imshow(results['crop_masks']['green_mask'], cmap='gray')
    axes[0, 1].set_title('Green Vegetation Mask')
    axes[0, 1].axis('off')
    
    # NDVI mask
    axes[0, 2].imshow(results['crop_masks']['ndvi_mask'], cmap='gray')
    axes[0, 2].set_title('NDVI Mask')
    axes[0, 2].axis('off')
    
    # Combined mask
    axes[1, 0].imshow(results['crop_masks']['combined_mask'], cmap='gray')
    axes[1, 0].set_title('Combined Crop Mask')
    axes[1, 0].axis('off')
    
    # NDVI values
    im = axes[1, 1].imshow(results['crop_masks']['ndvi_values'], cmap='RdYlGn')
    axes[1, 1].set_title('NDVI Values')
    axes[1, 1].axis('off')
    plt.colorbar(im, ax=axes[1, 1])
    
    # Health metrics bar chart
    metrics = ['Health Score', 'Coverage %', 'NDVI', 'Green Intensity']
    values = [
        results['health_metrics']['health_score'],
        results['health_metrics']['crop_coverage'],
        results['health_metrics']['avg_ndvi'] * 100,
        results['health_metrics']['avg_green_intensity']
    ]
    axes[1, 2].bar(metrics, values)
    axes[1, 2].set_title('Health Metrics')
    axes[1, 2].tick_params(axis='x', rotation=45)
    
    plt.tight_layout()
    plt.savefig('test_results.png', dpi=300, bbox_inches='tight')
    plt.show()
    
    print("📊 Test results visualization saved as 'test_results.png'")

if __name__ == "__main__":
    # Run tests
    results = test_processor()
    
    # Visualize results
    visualize_test_results(results)
    
    # Print summary
    print("\n📋 TEST SUMMARY:")
    print(f"Health Score: {results['health_metrics']['health_score']:.1f}/100")
    print(f"Crop Coverage: {results['health_metrics']['crop_coverage']:.1f}%")
    print(f"Estimated Yield: {results['yield_estimate']['estimated_yield_kg']:.1f} kg")
    print(f"Recommendations: {len(results['report']['recommendations'])}")
```

```bash:/Users/administrator/Workspace/drones/setup.sh
#!/bin/bash

# Harvest Measurement Program Setup Script

echo "🌾 Harvest Measurement Program Setup"
echo "===================================="

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed. Please install Python 3 first."
    exit 1
fi

echo "✅ Python 3 found: $(python3 --version)"

# Create virtual environment
echo "📦 Creating virtual environment..."
python3 -m venv harvest_env

# Activate virtual environment
echo " Activating virtual environment..."
source harvest_env/bin/activate

# Upgrade pip
echo "⬆️ Upgrading pip..."
pip install --upgrade pip

# Install requirements
echo "📥 Installing requirements..."
pip install -r requirements.txt

echo ""
echo "🎉 Setup completed successfully!"
echo ""
echo "To run the application:"
echo "1. Activate the virtual environment: source harvest_env/bin/activate"
echo "2. Run the app: python run_app.py"
echo ""
echo "Or run directly:"
echo "streamlit run harvest_measurement.py"
```

```toml:/Users/administrator/Workspace/drones/.streamlit/config.toml
[theme]
primaryColor = "#1f77b4"
backgroundColor = "#ffffff"
secondaryBackgroundColor = "#f0f2f6"
textColor = "#262730"

[server]
headless = true
port = 8501
enableCORS = false
enableXsrfProtection = false

[browser]
gatherUsageStats = false
```

Perfect! I've successfully created all the files for your Harvest measurement program in the `/Users/administrator/Workspace/drones` directory. Here's what has been saved:

## 📁 **Files Created:**

### **Core Application Files:**
- **`harvest_measurement.py`** - Main Streamlit application with advanced image processing
- **`config.py`** - Configuration file with all parameters and crop types
- **`run_app.py`** - Easy launcher script
- **`requirements.txt`** - All necessary Python dependencies

### **Additional Files:**
- **`utils.py`** - Utility functions for validation and export
- **`test_harvest.py`** - Test script with synthetic data generation
- **`setup.sh`** - Automated setup script for easy installation
- **`.streamlit/config.toml`** - Streamlit configuration
- **`README.md`** - Comprehensive documentation

## 🚀 **To Get Started:**

1. **Navigate to the directory:**
   ```bash
   cd /Users/administrator/Workspace/drones
   ```

2. **Quick Setup (recommended):**
   ```bash
   chmod +x setup.sh
   ./setup.sh
   ```

3. **Manual Setup:**
   ```bash
   pip install -r requirements.txt
   python run_app.py
   ```

4. **Test the system:**
   ```bash
   python test_harvest.py
   ```

## 🌾 **Key Features:**

- **Advanced Image Processing**: Multiple crop de

