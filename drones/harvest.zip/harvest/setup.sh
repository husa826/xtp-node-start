#!/bin/bash

# Harvest Measurement Program Setup Script

echo "🌾 Harvest Measurement Program Setup"
echo "===================================="

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed. Please install Python 3 first."
    exit 1
fi

echo "✅ Python 3 found: $(python3 --version)"

# Check if virtual environment already exists
if [ -d "venv" ]; then
    echo "⚠️  Virtual environment 'venv' already exists."
    read -p "Do you want to recreate it? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo "🗑️  Removing existing virtual environment..."
        rm -rf venv
    else
        echo "📦 Using existing virtual environment..."
        source venv/bin/activate
        echo "📥 Installing/updating requirements..."
        pip install -r requirements.txt
        echo ""
        echo "🎉 Setup completed successfully!"
        echo ""
        echo "To run the application:"
        echo "1. Activate the virtual environment: source venv/bin/activate"
        echo "2. Run the app: python run_app.py"
        echo ""
        echo "To deactivate the virtual environment: deactivate"
        exit 0
    fi
fi

# Create virtual environment
echo "📦 Creating virtual environment..."
python3 -m venv venv

# Activate virtual environment
echo "🔧 Activating virtual environment..."
source venv/bin/activate

# Upgrade pip
echo "⬆️ Upgrading pip..."
pip install --upgrade pip

# Install setuptools and wheel
echo "🔧 Installing build tools..."
pip install setuptools wheel

# Install requirements
echo "📥 Installing requirements..."
pip install -r requirements.txt

echo ""
echo "🎉 Setup completed successfully!"
echo ""
echo "📋 Next steps:"
echo "1. Activate the virtual environment: source venv/bin/activate"
echo "2. Run the application: python run_app.py"
echo ""
echo "💡 Tips:"
echo "- To deactivate the virtual environment: deactivate"
echo "- To reactivate later: source venv/bin/activate"
echo "- The virtual environment is located in the 'venv' directory"
echo ""
echo "🚀 Ready to analyze your harvest images!"