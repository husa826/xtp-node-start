"""
Test script for Harvest Measurement Program
"""

import cv2
import numpy as np
from harvest_measurement import HarvestMeasurementProcessor
import matplotlib.pyplot as plt

def create_test_image():
    """
    Create a synthetic test image for testing
    """
    # Create a 500x500 image
    image = np.zeros((500, 500, 3), dtype=np.uint8)
    
    # Add soil background (brown)
    image[:, :] = [139, 69, 19]
    
    # Add crop areas (green)
    # Healthy crop area
    cv2.rectangle(image, (50, 50), (200, 200), (34, 139, 34), -1)
    
    # Less healthy crop area
    cv2.rectangle(image, (250, 50), (400, 200), (107, 142, 35), -1)
    
    # Bare soil area
    cv2.rectangle(image, (50, 250), (200, 400), (160, 82, 45), -1)
    
    # Mixed area
    cv2.rectangle(image, (250, 250), (400, 400), (85, 107, 47), -1)
    
    return image

def test_processor():
    """
    Test the HarvestMeasurementProcessor
    """
    print("🧪 Testing Harvest Measurement Processor...")
    
    # Create processor
    processor = HarvestMeasurementProcessor()
    
    # Create test image
    test_image = create_test_image()
    
    # Test preprocessing
    print("Testing image preprocessing...")
    processed = processor.preprocess_image(test_image)
    print(f"✅ Preprocessing completed. Image shape: {processed['original'].shape}")
    
    # Test crop detection
    print("Testing crop detection...")
    crop_masks = processor.detect_crop_areas(processed)
    print(f"✅ Crop detection completed. Found {np.sum(crop_masks['combined_mask'] > 0)} crop pixels")
    
    # Test health analysis
    print("Testing health analysis...")
    health_metrics = processor.analyze_crop_health(processed, crop_masks)
    print(f"✅ Health analysis completed. Health score: {health_metrics['health_score']:.1f}")
    
    # Test yield estimation
    print("Testing yield estimation...")
    yield_estimate = processor.estimate_yield(health_metrics, 1000, 'wheat')
    print(f"✅ Yield estimation completed. Estimated yield: {yield_estimate['estimated_yield_kg']:.1f} kg")
    
    # Test report generation
    print("Testing report generation...")
    report = processor.generate_report(health_metrics, yield_estimate)
    print(f"✅ Report generation completed. Generated {len(report['recommendations'])} recommendations")
    
    print("\n🎉 All tests passed successfully!")
    
    return {
        'processed': processed,
        'crop_masks': crop_masks,
        'health_metrics': health_metrics,
        'yield_estimate': yield_estimate,
        'report': report
    }

def visualize_test_results(results):
    """
    Visualize test results
    """
    fig, axes = plt.subplots(2, 3, figsize=(15, 10))
    
    # Original image
    axes[0, 0].imshow(results['processed']['original'])
    axes[0, 0].set_title('Original Test Image')
    axes[0, 0].axis('off')
    
    # Green mask
    axes[0, 1].imshow(results['crop_masks']['green_mask'], cmap='gray')
    axes[0, 1].set_title('Green Vegetation Mask')
    axes[0, 1].axis('off')
    
    # NDVI mask
    axes[0, 2].imshow(results['crop_masks']['ndvi_mask'], cmap='gray')
    axes[0, 2].set_title('NDVI Mask')
    axes[0, 2].axis('off')
    
    # Combined mask
    axes[1, 0].imshow(results['crop_masks']['combined_mask'], cmap='gray')
    axes[1, 0].set_title('Combined Crop Mask')
    axes[1, 0].axis('off')
    
    # NDVI values
    im = axes[1, 1].imshow(results['crop_masks']['ndvi_values'], cmap='RdYlGn')
    axes[1, 1].set_title('NDVI Values')
    axes[1, 1].axis('off')
    plt.colorbar(im, ax=axes[1, 1])
    
    # Health metrics bar chart
    metrics = ['Health Score', 'Coverage %', 'NDVI', 'Green Intensity']
    values = [
        results['health_metrics']['health_score'],
        results['health_metrics']['crop_coverage'],
        results['health_metrics']['avg_ndvi'] * 100,
        results['health_metrics']['avg_green_intensity']
    ]
    axes[1, 2].bar(metrics, values)
    axes[1, 2].set_title('Health Metrics')
    axes[1, 2].tick_params(axis='x', rotation=45)
    
    plt.tight_layout()
    plt.savefig('test_results.png', dpi=300, bbox_inches='tight')
    plt.show()
    
    print("📊 Test results visualization saved as 'test_results.png'")

if __name__ == "__main__":
    # Run tests
    results = test_processor()
    
    # Visualize results
    visualize_test_results(results)
    
    # Print summary
    print("\n📋 TEST SUMMARY:")
    print(f"Health Score: {results['health_metrics']['health_score']:.1f}/100")
    print(f"Crop Coverage: {results['health_metrics']['crop_coverage']:.1f}%")
    print(f"Estimated Yield: {results['yield_estimate']['estimated_yield_kg']:.1f} kg")
    print(f"Recommendations: {len(results['report']['recommendations'])}")
```

```

