#!/usr/bin/env python3
"""
Harvest Measurement Program - Drone Image Analysis
Run this script to start the Streamlit application
"""

import subprocess
import sys
import os

def install_requirements():
    """Install required packages"""
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("✅ Requirements installed successfully!")
    except subprocess.CalledProcessError as e:
        print(f"❌ Error installing requirements: {e}")
        return False
    return True

def run_app():
    """Run the Streamlit application"""
    try:
        print("🚀 Starting Harvest Measurement Program...")
        subprocess.run([sys.executable, "-m", "streamlit", "run", "harvest_measurement.py"])
    except KeyboardInterrupt:
        print("\n👋 Application stopped by user")
    except Exception as e:
        print(f"❌ Error running application: {e}")

if __name__ == "__main__":
    print("🌾 Harvest Measurement Program")
    print("=" * 40)
    
    # Check if requirements.txt exists
    if not os.path.exists("requirements.txt"):
        print("❌ requirements.txt not found!")
        sys.exit(1)
    
    # Install requirements
    if install_requirements():
        # Run the application
        run_app()
    else:
        print("❌ Failed to install requirements. Please install manually:")
        print("pip install -r requirements.txt")
        print("streamlit run harvest_measurement.py")

